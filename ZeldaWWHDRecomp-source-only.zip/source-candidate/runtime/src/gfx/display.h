// The display as seen by a renderer: how the finished TV and GamePad pictures are laid out in the
// windows each frame (display_modes.cpp, shared by the AppKit host in display.mm and the SDL host).
// Plain C++ so the Vulkan renderer can use it.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace gfx {

// pixel rectangle in the target (drawable), top-left origin
struct Box { float x = 0, y = 0, w = 0, h = 0; };

// What to draw this frame (render thread, once per swap)
struct PresentPlan {
    float dw = 0, dh = 0;      // size the TV layout is for: the TV drawable, or WWHD_SIM_SCREEN
    bool sim = false;          // WWHD_SIM_SCREEN: the window itself still gets a layout for its drawable
    Box tv, pip;               // TV picture; GamePad overlay (pip_on)
    bool pip_on = false;
    bool pip_wanted = false;   // the overlay is up this frame (pip_on also needs a GamePad picture)
    float scale = 1;           // TV picture scale (target pixels per source pixel)
    float pip_opacity = 1;
    bool drc_window = false;   // the GamePad window is shown: present the GamePad picture there
    int filter = 0;            // picture scaling: 0 smooth, 1 sharp, 2 integer
    bool drc_only = false;     // GamePad-only mode: pip is the GamePad picture fitted to the window, no TV picture
    Box button;                // touch screens: the view button (display_modes.h), empty when not shown
    int button_dot = 0;        // the host's state dot on the button: 0 none, 1 on (green), 2 paused (yellow)
};

// start of a present: GamePad aspect for touch, "Match window" aspect, scripted touches, layout
PresentPlan display_plan(bool haveTv, float tvW, float tvH, bool haveDrc, float drcW, float drcH, float layerW, float layerH,
                         uint64_t frame, bool publish_input = true);
// the same layout for another target size (sim screen: the window's real drawable)
PresentPlan display_plan_for(const PresentPlan& p, float dw, float dh, float tvW, float tvH, float drcW, float drcH);
// GamePad window: its picture scaled to fit
Box display_layout(float dw, float dh, float tw, float th);
// WWHD_DUMP_PRESENT / capture: composed window pictures requested since the last present
std::vector<std::string> display_take_present_dumps();
void request_present_dump(const std::string& path);
void display_log_present_dump(const std::string& path, const PresentPlan& p, float tvW, float tvH);

}  // namespace gfx

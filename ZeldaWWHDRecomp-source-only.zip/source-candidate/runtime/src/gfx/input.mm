#include "../mods/fast_forward.h"
#include "../mods/mods.h"
#ifdef WWHD_HAS_VULKAN
#include "gfx/vulkan/stutter_trace.h"
#include "gfx/vulkan/headstart.h"
namespace gx2 { void checkpoint_vulkan_caches(); }
#endif
// Keyboard and GameController input, merged into one GamePad state.
//
// Which key or controller input drives which GamePad input is the controls mapping (input_map.h,
// edited in Input > Controls…). Defaults: WASD move, arrows camera, K/Space = A, J = B, L = X, I = Y,
// Q = L, E = R, Left Shift = ZL, C = ZR, Enter = +, Tab = -, H = Home, 1-4 = D-pad up/down/left/right,
// X = L-stick click, V = R-stick click; controllers use button positions (Xbox "A" = Wii U B),
// switchable to by-label with input_map::FaceLayout (issue #78).
#ifdef WWHD_IOS
#import <UIKit/UIKit.h>
#include "platform/ios/ios.h"
#include "platform/ios/runtime_test.h"
#include "platform/ios/touch_layout.h"
#include "guest_addr.h"
#else
#import <AppKit/AppKit.h>
#endif
#import <GameController/GameController.h>
#import <QuartzCore/QuartzCore.h>  // CACurrentMediaTime
#include "platform/keycodes.h"

#include <cmath>
#include <mutex>

#include "input.h"
#include "input_map.h"
#include "mouse_bindings.h"
#include "mods/mods.h"
#include "renderer.h"
#include "../runtime.h"
#include "../savestate.h"
#include "../screenshot.h"
#include "../true60.h"
#include "../motion/motion.h"
#include "../overlay/overlay.h"
#include "../overlay/release_gate.h"

#include <memory>
#include <string>
#include <vector>

namespace gfx { void request_capture(); bool menu_hotkey(uint16_t keyCode); bool controls_window_is_key(); bool text_input_key(void* event); }
namespace mods { void filter_pad(input::PadState& s); bool host_key_down(uint16_t code); void update_gyro_mouse(); }  // mods/

namespace input {

static std::mutex g_mu;
static MouseBindings g_mouse_bindings;
void release_mouse_bindings() { std::lock_guard lk(g_mu); g_mouse_bindings.consume(); }
void mouse_binding_button(uint64_t device, int button, bool down, bool eligible) {
    std::lock_guard lk(g_mu); g_mouse_bindings.button(device, button, down, eligible);
}
void mouse_binding_wheel(float delta, bool eligible) {
    std::lock_guard lk(g_mu); g_mouse_bindings.wheel(delta, eligible);
}
static bool g_keys[256];
static PadState g_pad;  // controller part, refreshed on the main thread
#ifdef WWHD_IOS
static PadState g_touch_pad;
static std::atomic<bool> g_motion_active{true};
void set_motion_active(bool active) { g_motion_active=active; }
void set_touch_pad(const PadState& pad) { std::lock_guard lk(g_mu); g_touch_pad=pad; }
#endif
static bool g_touch;
static float g_tx, g_ty;

void set_touch(bool down, float x, float y) {
    std::lock_guard<std::mutex> lk(g_mu);
    g_touch = down;
    g_tx = x;
    g_ty = y;
}

// keys held by WWHD_KEYS (debug), merged with the real keyboard before the mapping is applied
static bool g_script_keys[256];

static PadState keyboard_state(bool use_host) {
    bool keys[256];
    for (int i = 0; i < 256; i++) keys[i] = (use_host && g_keys[i]) || g_script_keys[i];
    return g_mouse_bindings.read(input_map::current(), use_host && mods::mouse_captured() && !overlay::captures(), keys, screenshot::key_down, !mods::first_person_wheel());
}

static input_map::AppleFaceLayout controller_face_layout(GCController* c) {
    return input_map::apple_face_layout(c.productCategory.UTF8String, c.vendorName.UTF8String);
}

// every mappable controller input of one controller, 0..1; false: not a gamepad
static bool device_values(GCController* c, float* v) {
    using namespace input_map;
    for (int i = 0; i < kPadCount; i++) v[i] = 0;
    auto put = [&](int p, float x) { if (x > v[p]) v[p] = x; };
    GCExtendedGamepad* g = c.extendedGamepad;
    if (!g) return false;
    {
        const auto layout = controller_face_layout(c);
        auto b = [&](GCControllerButtonInput* in, int p) {
            if (in) put(apple_face_input(layout, p), in.isPressed ? std::max(in.value, 0.51f) : std::min(in.value, 0.5f));
        };
        b(g.buttonA, kPadA); b(g.buttonB, kPadB); b(g.buttonX, kPadX); b(g.buttonY, kPadY);
        b(g.leftShoulder, kPadLB); b(g.rightShoulder, kPadRB);
        b(g.leftTrigger, kPadLT); b(g.rightTrigger, kPadRT);
        b(g.buttonMenu, kPadMenu); b(g.buttonOptions, kPadOptions); b(g.buttonHome, kPadHome);
        b(g.leftThumbstickButton, kPadL3); b(g.rightThumbstickButton, kPadR3);
        b(g.dpad.up, kPadDUp); b(g.dpad.down, kPadDDown); b(g.dpad.left, kPadDLeft); b(g.dpad.right, kPadDRight);
        auto stick = [&](GCControllerDirectionPad* d, int up, int down, int left, int right) {
            float x = d.xAxis.value, y = d.yAxis.value;
            put(right, std::max(x, 0.f)); put(left, std::max(-x, 0.f));
            put(up, std::max(y, 0.f)); put(down, std::max(-y, 0.f));
        };
        stick(g.leftThumbstick, kPadLSUp, kPadLSDown, kPadLSLeft, kPadLSRight);
        stick(g.rightThumbstick, kPadRSUp, kPadRSDown, kPadRSLeft, kPadRSRight);
    }
    return true;
}

// each connected controller's values, keyed by the controller: a reconnected one is a new object
static const std::vector<std::pair<uintptr_t, overlay::PadValues>>& devices_values() {
    // Main-thread consumers use this snapshot immediately; retain its allocation between polls.
    static std::vector<std::pair<uintptr_t, overlay::PadValues>> out;
    out.clear();
    for (GCController* c in [GCController controllers]) {
        overlay::PadValues d;
        if (device_values(c, d.data())) out.emplace_back((uintptr_t)(__bridge void*)c, d);
    }
    return out;
}

// every mappable controller input, 0..1, the strongest over all connected controllers
void controller_values(float* v) {
    using namespace input_map;
    for (int i = 0; i < kPadCount; i++) v[i] = 0;
    for (const auto& [id, d] : devices_values())
        for (int p = 0; p < kPadCount; p++) v[p] = std::max(v[p], d[p]);
}

// ---- the labels printed on a pad's face buttons (issue #78's Automatic preset)

// The letter on one face button, from its SF Symbol name ("a.circle", "xmark.circle") or its
// localized name ("Button A"). The parsing is input_map's, so input_map_test can cover the names
// real pads report. kUnknown when the host does not say.
static input_map::FaceLabel button_letter(GCControllerButtonInput* in) {
    if (!in) return input_map::FaceLabel::kUnknown;
    NSString* s = nil;
    if (@available(macOS 11.0, *)) s = in.sfSymbolsName.length ? in.sfSymbolsName : in.localizedName;
    return input_map::face_label_from_text(s.UTF8String);
}

// A pad whose buttons do not name themselves (older MFi, some HID): guess the family from what it
// says it is. Xbox/PlayStation letters sit where the letters are; Nintendo's are the other way.
static void family_letters(GCController* c, input_map::FaceLabel out[4]) {
    using FL = input_map::FaceLabel;
    const auto family = input_map::apple_pad_family(c.productCategory.UTF8String, c.vendorName.UTF8String, out);
    if (family == input_map::PadFamily::kNintendo) {
        out[0] = FL::kB; out[1] = FL::kA; out[2] = FL::kY; out[3] = FL::kX;  // south, east, west, north
    } else if (family == input_map::PadFamily::kPlayStation) {  // the Xbox letters' places; the in-game prompts show the shapes (#143)
        out[0] = FL::kCross; out[1] = FL::kCircle; out[2] = FL::kSquare; out[3] = FL::kTriangle;
    } else if (family == input_map::PadFamily::kXbox) {
        out[0] = FL::kA; out[1] = FL::kB; out[2] = FL::kX; out[3] = FL::kY;
    }
}

// Connect order of the pads we have seen: GameController's own list is not that order, and the
// Automatic preset follows the first pad still connected.
static NSMutableArray<GCController*>* g_connect_order;

static void note_dominant_labels() {
    using FL = input_map::FaceLabel;
    FL labels[4] = {FL::kUnknown, FL::kUnknown, FL::kUnknown, FL::kUnknown};
    input_map::PadFamily family = input_map::PadFamily::kUnknown;
    GCController* dominant = nil;
    for (GCController* c in [g_connect_order copy]) {
        if (c.extendedGamepad) { dominant = c; break; }
    }
    if (dominant) {
        GCExtendedGamepad* g = dominant.extendedGamepad;
        GCControllerButtonInput* face[4] = {g.buttonA, g.buttonB, g.buttonX, g.buttonY};  // framework element order
        bool any = false;
        for (int i = 0; i < 4; i++) {
            labels[i] = button_letter(face[i]);
            any |= labels[i] != FL::kUnknown;
        }
        input_map::apple_face_labels(controller_face_layout(dominant), labels);
        family = input_map::apple_pad_family(dominant.productCategory.UTF8String, dominant.vendorName.UTF8String, labels);
        if (!any) family_letters(dominant, labels);  // nothing printed we can read: guess the family
    }
#ifdef WWHD_IOS
    input_map::note_controller_labels(labels, family);
#else
    input_map::note_controller_labels(labels, family, true);  // desktop keeps the last family on disconnect
#endif
    if (dominant && input_map::apple_face_workaround(input_map::current(), controller_face_layout(dominant)))
        LOG("[input] Nintendo pad with by-label bindings: if these were the old macOS workaround, "
            "select Input > Face buttons > By position (Nintendo) or Automatic (#181). Saved bindings kept.");
}

// the latest controller_values (the timer below), for the settings overlay's navigation
static float g_host_values[input_map::kPadCount];
void host_controller_values(float* v) {
    std::lock_guard<std::mutex> lk(g_mu);
    std::copy(g_host_values, g_host_values + input_map::kPadCount, v);
}

void held_keys(bool* keys) {
    std::lock_guard<std::mutex> lk(g_mu);
    for (int i = 0; i < 256; i++) keys[i] = g_keys[i] || g_script_keys[i];
}

void release_keys() {
    mods::fast_forward_reset();
    mods::lock_on_reset();
    std::lock_guard<std::mutex> lk(g_mu);
    g_mouse_bindings.consume();
    memset(g_keys, 0, sizeof(g_keys));
#ifdef WWHD_IOS
    g_touch_pad={};
#endif
}

// Rumble would go to the host game controllers through GameController.framework (GCController
// haptics); this host has none of its own yet (see platform/input_sdl.cpp for the SDL host, which
// does rumble). The game's requests are kept by rumble.h all the same.
bool has_rumble() { return false; }
void stop_rumble_now() {}

#ifndef WWHD_IOS
// modifier keys arrive as flagsChanged; the device-dependent bits tell left from right
static bool modifier_down(uint16_t code, NSEventModifierFlags f) {
    switch (code) {
    case kVK_Shift: return f & 0x02;          // NX_DEVICELSHIFTKEYMASK
    case kVK_RightShift: return f & 0x04;     // NX_DEVICERSHIFTKEYMASK
    case kVK_Control: return f & 0x01;        // NX_DEVICELCTLKEYMASK
    case kVK_RightControl: return f & 0x2000; // NX_DEVICERCTLKEYMASK
    case kVK_Option: return f & 0x20;         // NX_DEVICELALTKEYMASK
    case kVK_RightOption: return f & 0x40;    // NX_DEVICERALTKEYMASK
    case kVK_CapsLock: return f & NSEventModifierFlagCapsLock;
    default: return false;
    }
}

// debug: WWHD_TEST_POST_KEYS=300:F1,400:Cmd+Comma,410:Down,420:Return,430:K/30 (held 30 frames) posts key presses (down, then up) at TV frames
// into the app's event queue, so they take the real path (event monitors, menu key equivalents) even
// in hidden test runs. Only the settings overlay and the menus react to them, not the game.
// 500:Text=Tetra types text (one key press per character, carrying it) into the game's text prompt.
static const NSTimeInterval kTestKeyTimestamp = 4242.0;
static void start_test_keys() {
    const char* e = getenv("WWHD_TEST_POST_KEYS");
    if (!e || !*e) return;
    struct Press { uint64_t frame; uint16_t code; NSEventModifierFlags flags; NSString* chars; uint64_t hold; };
    auto presses = std::make_shared<std::vector<Press>>();
    for (const char* p = e; *p;) {
        char* end;
        uint64_t f = strtoull(p, &end, 10);
        if (*end != ':') break;
        p = end + 1;
        size_t len = strcspn(p, ",");
        std::string k(p, len);
        p += len + (p[len] == ',');
        Press pr{f, 0, 0, @"", 0};
        if (k.rfind("Text=", 0) == 0) {  // one press per character (key code: the A key; the characters count)
            NSString* t = [NSString stringWithUTF8String:k.c_str() + 5];
            for (NSUInteger i = 0; i < t.length; i++)
                presses->push_back({f + i * 2, kVK_ANSI_A, 0, [t substringWithRange:NSMakeRange(i, 1)], 0});
            continue;
        }
        if (size_t sl = k.find('/'); sl != std::string::npos) {  // Key/<frames>: held that many frames
            pr.hold = strtoull(k.c_str() + sl + 1, nullptr, 10);
            k.resize(sl);
        }
        if (k.rfind("Cmd+", 0) == 0) { pr.flags = NSEventModifierFlagCommand; k = k.substr(4); }
        if (k == "F1") { pr.code = kVK_F1; pr.chars = [NSString stringWithFormat:@"%C", (unichar)NSF1FunctionKey]; pr.flags |= NSEventModifierFlagFunction; }
        else if (k == "Comma") { pr.code = kVK_ANSI_Comma; pr.chars = @","; }
        else if (k == "Escape") { pr.code = kVK_Escape; pr.chars = @"\x1b"; }
        else if (int c = input_map::key_from_id(k); c != input_map::kNoKey) pr.code = (uint16_t)c;  // controls.json key names
        else { LOG("[input] WWHD_TEST_POST_KEYS: unknown key %s", k.c_str()); continue; }
        presses->push_back(pr);
    }
    // a held key: its key up as a separate entry, later
    for (size_t i = 0, n = presses->size(); i < n; i++)
        if ((*presses)[i].hold) {
            Press up = (*presses)[i];
            up.frame += up.hold;
            up.hold = ~0ull;  // marks the release
            presses->push_back(up);
        }
    std::stable_sort(presses->begin(), presses->end(), [](const Press& a, const Press& b) { return a.frame < b.frame; });
    [NSTimer scheduledTimerWithTimeInterval:1.0 / 120 repeats:YES block:^(NSTimer* t) {
        uint64_t frame = render::frame_count();
        while (!presses->empty() && frame >= presses->front().frame) {
            Press pr = presses->front();
            presses->erase(presses->begin());
            LOG("[input] test key %s%u %s at frame %llu", pr.flags & NSEventModifierFlagCommand ? "Cmd+" : "", pr.code,
                pr.hold == ~0ull ? "up" : pr.hold ? "down" : "press", (unsigned long long)frame);
            std::vector<NSEventType> types = pr.hold == ~0ull ? std::vector<NSEventType>{NSEventTypeKeyUp}
                                             : pr.hold         ? std::vector<NSEventType>{NSEventTypeKeyDown}
                                                               : std::vector<NSEventType>{NSEventTypeKeyDown, NSEventTypeKeyUp};
            for (NSEventType type : types) {
                NSEvent* ev = [NSEvent keyEventWithType:type location:NSZeroPoint modifierFlags:pr.flags timestamp:kTestKeyTimestamp
                                           windowNumber:0 context:nil characters:pr.chars charactersIgnoringModifiers:pr.chars
                                              isARepeat:NO keyCode:pr.code];
                [NSApp postEvent:ev atStart:NO];
            }
        }
        if (presses->empty()) [t invalidate];
    }];
}

#endif

// ---- motion sensors (motion/motion.h) ----
// GameController.framework reports the gyro and accelerometer of DualSense, DualShock 4, Switch Pro and
// Joy-Con controllers (macOS 11+). Its frame (as CoreMotion's, for a controller lying flat): x right, y
// towards the top (away from the player), z up out of the face; acceleration in g with gravity's sign
// (at rest flat: z = -1). motion.h takes SDL's frame (x right, y up, z towards the player, m/s^2 of
// specific force), so: sdl = (x, z, -y), acceleration negated.
// WWHD_GYRO_LOG=1 logs a raw sample twice a second (to check the axes with a new controller).
static void update_motion_sensors() API_AVAILABLE(macos(11.0)) {
    const bool want = motion::wants_controller_sensors() && !getenv("WWHD_NO_HOST_INPUT")
#ifdef WWHD_IOS
        && g_motion_active.load() && !ios::controls_block_input()
#endif
        ;
    static NSMutableSet* active = [NSMutableSet set];  // controllers whose handler is installed
    int n = 0;
    NSArray<GCController*>* connected = [GCController controllers];
    // controllers that went away: their handler goes with them (a reconnected controller is a new object)
    for (GCController* c in [active allObjects])
        if (![connected containsObject:c]) {
            [active removeObject:c];
            c.motion.valueChangedHandler = nil;
            motion::controller_gone((uint64_t)(uintptr_t)(__bridge void*)c);
        }
    for (GCController* c in connected) {
        GCMotion* m = c.motion;
        if (!m || !m.hasRotationRate) continue;
        n++;
        const bool on = [active containsObject:c];
        // the system can switch a controller's sensors off (another app, sleep); while the gyro is wanted they
        // are switched on again (this runs every quarter second)
        if (want && on && m.sensorsRequireManualActivation && !m.sensorsActive) {
            LOG("[gyro] %s: its motion sensors were off, switching them on again", c.vendorName.UTF8String ?: "controller");
            m.sensorsActive = YES;
        }
        if (want == on) continue;
        if (want) {
            [active addObject:c];
            if (m.sensorsRequireManualActivation) m.sensorsActive = YES;
            const uint64_t id = (uint64_t)(uintptr_t)(__bridge void*)c;
            m.valueChangedHandler = ^(GCMotion* mm) {
                if (overlay::blocks_input()) return;
#ifdef WWHD_IOS
                if(!g_motion_active.load() || ios::controls_block_input())return;
#endif
                GCRotationRate r = mm.rotationRate;
                GCAcceleration a = mm.hasGravityAndUserAcceleration
                                       ? GCAcceleration{mm.gravity.x + mm.userAcceleration.x, mm.gravity.y + mm.userAcceleration.y,
                                                        mm.gravity.z + mm.userAcceleration.z}
                                       : mm.acceleration;
                const float g = 9.80665f;
                float gyro[3] = {(float)r.x, (float)r.z, (float)-r.y};
                float acc[3] = {(float)-a.x * g, (float)-a.z * g, (float)a.y * g};
                static const bool log = getenv("WWHD_GYRO_LOG") != nullptr;
                static double last_log = 0;
                if (log && CACurrentMediaTime() - last_log > 0.5) {
                    last_log = CACurrentMediaTime();
                    LOG("[gyro] GameController raw: rate %.3f %.3f %.3f rad/s, acc %.3f %.3f %.3f g", r.x, r.y, r.z, a.x, a.y, a.z);
                }
                motion::controller_sample(id, 0, gyro, acc);
            };
        } else {
            [active removeObject:c];
            m.valueChangedHandler = nil;
            if (m.sensorsRequireManualActivation) m.sensorsActive = NO;
            motion::controller_gone((uint64_t)(uintptr_t)(__bridge void*)c);
        }
    }
    motion::set_gyro_controllers(n);
}

void init() {
    if (const char* v = getenv("WWHD_OVERLAY_MOUSE_HANDOFF"); v && !strcmp(v,"0"))
        LOG("[overlay] diagnostic mouse handoff disabled (WWHD_OVERLAY_MOUSE_HANDOFF=0)");
    input_map::load_startup();
#ifndef WWHD_IOS
    start_test_keys();
    NSEventMask mask = NSEventMaskKeyDown | NSEventMaskKeyUp | NSEventMaskFlagsChanged;
    [NSEvent addLocalMonitorForEventsMatchingMask:mask handler:^NSEvent*(NSEvent* e) {
        // keep Cmd-Q etc.; in an overlay text field the editing shortcuts (Cmd+A/C/V/X/Z) go to the overlay
        if (e.modifierFlags & NSEventModifierFlagCommand) {
            const uint16_t k = e.keyCode;
            const bool editing = k == kVK_ANSI_A || k == kVK_ANSI_C || k == kVK_ANSI_V || k == kVK_ANSI_X || k == kVK_ANSI_Z;
            if (!(editing && overlay::wants_text())) return e;
            if (k == kVK_ANSI_V && e.type == NSEventTypeKeyDown) {
                NSString* s = [NSPasteboard.generalPasteboard stringForType:NSPasteboardTypeString];
                overlay::set_clipboard_text(s ? s.UTF8String : "");
            }
        }
        if (NSApp.keyWindow.sheetParent || NSApp.modalWindow) return e;  // text prompt has focus
        if (gfx::controls_window_is_key()) return e;  // Controls window: keys go to it, not the game
        uint16_t code = e.keyCode & 0xFF;
        const bool posted = e.timestamp == kTestKeyTimestamp;  // WWHD_TEST_POST_KEYS
        if (getenv("WWHD_NO_HOST_INPUT") && !posted) return e;
        {
            // settings overlay (overlay/overlay.h): F1 opens and closes it; while open it has the keyboard
            NSEventModifierFlags f = e.modifierFlags;
            int m = (f & NSEventModifierFlagShift ? overlay::kShift : 0) | (f & NSEventModifierFlagControl ? overlay::kCtrl : 0) |
                    (f & NSEventModifierFlagOption ? overlay::kAlt : 0) | (f & NSEventModifierFlagCommand ? overlay::kSuper : 0);
            bool down = e.type == NSEventTypeKeyDown || (e.type == NSEventTypeFlagsChanged && modifier_down(code, f));
            bool repeat = e.type != NSEventTypeFlagsChanged && e.isARepeat;
            if (gfx::text_input_key((__bridge void*)e)) return nil;  // the game's text prompt: typed text
            if (overlay::key(code, down, repeat, m)) {
                // typed characters for the overlay's text fields (not shortcuts, not function/arrow keys)
                if (e.type == NSEventTypeKeyDown && !(m & (overlay::kCtrl | overlay::kSuper)) && overlay::is_open()) {
                    NSString* chars = e.characters ?: @"";
                    NSMutableString* typed = [NSMutableString string];
                    for (NSUInteger i = 0; i < chars.length; ++i) {
                        unichar c = [chars characterAtIndex:i];
                        if (c < 0x20 || c == 0x7F || (c >= 0xF700 && c <= 0xF8FF)) continue;  // control, NSF*FunctionKey
                        [typed appendFormat:@"%C", c];
                    }
                    if (typed.length) overlay::text(typed.UTF8String);
                }
                return nil;
            }
            // the Screenshot binding (F10 by default; posted test keys take this path too)
            if (e.type == NSEventTypeKeyDown && !e.isARepeat && screenshot::key_down(code)) return nil;
            if (posted) return nil;  // test keys only reach the overlay
        }
        std::lock_guard<std::mutex> lk(g_mu);
        if (e.type == NSEventTypeKeyDown && !e.isARepeat && mods::host_key_down(code)) return nil;  // e.g. Esc releases the mouse
        if (e.type == NSEventTypeKeyDown && !e.isARepeat && gfx::menu_hotkey(code)) return nil;
        // a repeat never presses a key: one held down while the overlay or the text prompt had the keyboard
        // (Enter that confirmed a name) stays out of the game until pressed again
        if (e.type == NSEventTypeKeyDown) g_keys[code] = g_keys[code] || !e.isARepeat;
        else if (e.type == NSEventTypeKeyUp) g_keys[code] = false;
        else g_keys[code] = modifier_down(code, e.modifierFlags);
        return nil;  // swallow, no system beep
    }];
    // drop held keys when the window loses focus
    [[NSNotificationCenter defaultCenter] addObserverForName:NSApplicationDidResignActiveNotification
                                                      object:nil queue:nil usingBlock:^(NSNotification*) {
        std::lock_guard<std::mutex> lk(g_mu);
        g_mouse_bindings.consume();
        memset(g_keys, 0, sizeof(g_keys));
    }];
#endif
    [GCController startWirelessControllerDiscoveryWithCompletionHandler:nil];
    // the Automatic face preset follows the pad that was plugged in first (issue #78 follow-up)
    g_connect_order = [NSMutableArray array];
    for (GCController* c in [GCController controllers]) [g_connect_order addObject:c];
    NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
    [nc addObserverForName:GCControllerDidConnectNotification object:nil queue:nil usingBlock:^(NSNotification* n) {
        GCController* c = n.object;
        if (c && ![g_connect_order containsObject:c]) [g_connect_order addObject:c];
        note_dominant_labels();
    }];
    [nc addObserverForName:GCControllerDidDisconnectNotification object:nil queue:nil usingBlock:^(NSNotification* n) {
        [g_connect_order removeObject:n.object];
        note_dominant_labels();
    }];
    note_dominant_labels();
    // GameController values are polled on the main thread
    [NSTimer scheduledTimerWithTimeInterval:1.0 / 240 repeats:YES block:^(NSTimer*) {
        float v[input_map::kPadCount], game[input_map::kPadCount];
        // inputs held while the overlay or the text prompt had them stay from the game until released,
        // one gate per controller as on the SDL host (overlay/release_gate.h, issue #153); the overlay
        // polls its controller shortcut on the overlay frame (and the platform shortcuts: an input one took
        // counts as captured, overlay/extensions.h)
        static overlay::DeviceGates<uintptr_t> gates;
        const auto& devices = devices_values();
        gates.combine(devices, overlay::captures() || overlay::shortcut_took_input(), v, game);
        PadState s = input_map::controller_state(input_map::current(), game);
        {
            std::lock_guard<std::mutex> lk(g_mu);
            g_pad = s;
            std::copy(v, v + input_map::kPadCount, g_host_values);
        }
        // gyro: sensors on or off with the source, the recalibrate binding, the mouse gyro's capture
        static int tick = 0;
        if (@available(macOS 11.0, *)) if (tick++ % 60 == 0) update_motion_sensors();
        if (!overlay::blocks_input() && !getenv("WWHD_NO_HOST_INPUT")) {
            bool keys[256];
            {
                std::lock_guard<std::mutex> lk(g_mu);
                std::copy(g_keys, g_keys + 256, keys);
            }
            motion::poll_recalibrate(game, keys);
            screenshot::poll_controller(game);  // a controller input bound to Screenshot
        }
        mods::update_gyro_mouse();
    }];
}

// debug: WWHD_PRESS=1000-1010:8000,1500-1505:0008 holds VPAD buttons (hex) during TV frame ranges
struct Press { uint64_t from, to; uint32_t bits; };
static std::vector<Press> scripted() {
    std::vector<Press> v;
    if (const char* e = getenv("WWHD_PRESS")) {
        unsigned long long a, b; unsigned bits; int n;
        while (sscanf(e, "%llu-%llu:%x%n", &a, &b, &bits, &n) == 3) {
            v.push_back({a, b, bits});
            e += n;
            if (*e != ',') break;
            e++;
        }
    }
    return v;
}

// debug: WWHD_KEYS=1200-1210:K,1300-1305:LeftShift+J holds keyboard keys (input_map key names)
// during TV frame ranges. Unlike WWHD_PRESS they go through the controls mapping, so a test can
// check a remapped controls file (also with WWHD_NO_HOST_INPUT=1).
struct KeyPress { uint64_t from, to; std::vector<int> codes; };
static std::vector<KeyPress> scripted_keys() {
    std::vector<KeyPress> v;
    if (const char* e = getenv("WWHD_KEYS")) {
        unsigned long long a, b; int n;
        while (sscanf(e, "%llu-%llu:%n", &a, &b, &n) == 2) {
            e += n;
            KeyPress kp{a, b, {}};
            for (;;) {
                size_t len = strcspn(e, "+,");
                int code = input_map::key_from_id(std::string(e, len));
                if (code == input_map::kNoKey) LOG("[input] WWHD_KEYS: unknown key %.*s", (int)len, e);
                else kp.codes.push_back(code);
                e += len;
                if (*e != '+') break;
                e++;
            }
            v.push_back(kp);
            if (*e != ',') break;
            e++;
        }
    }
    return v;
}

// debug: WWHD_STICK=9400-9600:0:1,... holds the left stick at (x, y) during TV frame ranges
// (WWHD_RSTICK: the same for the right stick)
struct Stick { uint64_t from, to; float x, y; };
static std::vector<Stick> scripted_stick(const char* var = "WWHD_STICK") {
    std::vector<Stick> v;
    if (const char* e = getenv(var)) {
        unsigned long long a, b; float x, y; int n;
        while (sscanf(e, "%llu-%llu:%f:%f%n", &a, &b, &x, &y, &n) == 4) {
            v.push_back({a, b, x, y});
            e += n;
            if (*e != ',') break;
            e++;
        }
    }
    return v;
}

// debug: timed test scenario, in real seconds from TV frame WWHD_TEST_ORIGIN (so a 30 fps and a 60 fps
// run get the same input at the same real time):
//   WWHD_TEST_STICK=2-5:0:1,...   left stick (x, y) from 2 s to 5 s
//   WWHD_TEST_RSTICK=2-5:1:0,...  right stick
//   WWHD_TEST_PRESS=3-3.1:8000    buttons (hex)
//   WWHD_TEST_MODE=2@0.5          60 fps mode at 0.5 s (0 off, 1 interpolation, 2 true 60)
//   WWHD_TEST_END=12              writes the file "test_done" at 12 s (the test script stops the game)
namespace {
struct TimedStick { double from, to; float x, y; };
struct TimedPress { double from, to; uint32_t bits; };
struct Scenario {
    uint64_t origin = 0;
    std::vector<TimedStick> sticks, rsticks;
    std::vector<TimedPress> presses;
    int mode = -1;
    double mode_at = 0, end = 0;
    Scenario() {
        if (const char* e = getenv("WWHD_TEST_ORIGIN")) origin = strtoull(e, nullptr, 10);
        auto timed_sticks = [](const char* e, std::vector<TimedStick>& out) {
            double a, b; float x, y; int n;
            while (e && sscanf(e, "%lf-%lf:%f:%f%n", &a, &b, &x, &y, &n) == 4) {
                out.push_back({a, b, x, y});
                e += n;
                if (*e != ',') break;
                e++;
            }
        };
        timed_sticks(getenv("WWHD_TEST_STICK"), sticks);
        timed_sticks(getenv("WWHD_TEST_RSTICK"), rsticks);
        if (const char* e = getenv("WWHD_TEST_PRESS")) {
            double a, b; unsigned bits; int n;
            while (sscanf(e, "%lf-%lf:%x%n", &a, &b, &bits, &n) == 3) {
                presses.push_back({a, b, bits});
                e += n;
                if (*e != ',') break;
                e++;
            }
        }
        if (const char* e = getenv("WWHD_TEST_MODE")) sscanf(e, "%d@%lf", &mode, &mode_at);
        if (const char* e = getenv("WWHD_TEST_END")) end = atof(e);
    }
};
}  // namespace
}  // namespace input
namespace interp { void set_mode(int m); uint64_t logic_steps(); }
namespace true60_test { void tick(double t, bool ended); void set_origin_step(uint64_t s); }
namespace input {
// WWHD_TEST_TOUCH=t0-t1:x:y,...: touches the GamePad screen at (x, y) (0..1) during scenario times
static bool g_test_touch = false;
static float g_test_tx = 0, g_test_ty = 0;
static bool apply_scenario(PadState& s) {
    static Scenario sc;
    // WWHD_TEST_ORIGIN_LOAD=n: the scenario starts n logic steps after the last save-state load (a
    // load completes asynchronously, so a fixed frame can fall a step apart between two runs)
    static const char* ol = getenv("WWHD_TEST_ORIGIN_LOAD");
    uint64_t ol_step = 0;
    // (the clock is the number of Link's full-pass executes since the load, true60::link_steps: the
    // pass at which a load lands differs between runs, and the steps after it are the game's)
    if (ol) {
        if (!true60::state_loaded()) return false;
        static uint64_t found = 0;
        if (!found) {
            int64_t past = (int64_t)true60::link_steps() - (int64_t)strtoull(ol, nullptr, 10);
            if (past < 0) return false;
            found = interp::logic_steps() - (uint64_t)past;  // the logic step at which the count reached it
        }
        ol_step = found;
        sc.origin = 1;
    }
    if (!sc.origin || (!ol && render::frame_count() < sc.origin)) return false;
    // scenario time = game time: full logic steps / 30 (frame-time hitches don't shift the input)
    static const uint64_t s0 = [ol_step] {
        if (ol_step) {
            LOG("[test] origin at logic step %llu (load + WWHD_TEST_ORIGIN_LOAD), logic step %llu", (unsigned long long)ol_step,
                (unsigned long long)ol_step);
            true60_test::set_origin_step(ol_step);
            return ol_step;
        }
        LOG("[test] origin at guest time %.4f s, logic step %llu", (double)timebase::now() / timebase::kTicksPerSec,
            (unsigned long long)interp::logic_steps());
        true60_test::set_origin_step(interp::logic_steps());
        return interp::logic_steps();
    }();
    // (with WWHD_TEST_ORIGIN_LOAD: the game's own step counter, which the load restores, is the clock)
    double t = (double)(interp::logic_steps() - s0) / 30.0;
    static std::atomic<bool> mode_set{false}, ended{false};
    static std::atomic<int> dbg{0};
    if (getenv("WWHD_TEST_DEBUG") && dbg++ % 30 == 0) LOG("[test] t=%.3f frame %llu", t, (unsigned long long)render::frame_count());
    if (sc.mode >= 0 && t >= sc.mode_at && !mode_set.exchange(true)) {
        LOG("[test] t=%.3f s: 60 fps mode %d", t, sc.mode);
        interp::set_mode(sc.mode);
    }
    // WWHD_TEST_MODES=m@t,m@t,...: further mode switches (0 off, 1 interpolation, 2 true 60)
    static std::vector<std::pair<double, int>> modes = [] {
        std::vector<std::pair<double, int>> v;
        for (const char* e = getenv("WWHD_TEST_MODES"); e && *e;) {
            int m; double at; int n;
            if (sscanf(e, "%d@%lf%n", &m, &at, &n) != 2) break;
            v.push_back({at, m});
            e += n;
            if (*e != ',') break;
            e++;
        }
        return v;
    }();
    for (auto& [at, m] : modes)
        if (m >= 0 && t >= at) {
            LOG("[test] t=%.3f s: 60 fps mode %d", t, m);
            interp::set_mode(m);
            m = -1;
        }
    true60_test::tick(t, sc.end > 0 && t >= sc.end);  // test aids (true60_test.cpp)
    if (sc.end > 0 && t >= sc.end && !ended.exchange(true)) {
        LOG("[test] t=%.3f s: end", t);
        #ifdef WWHD_HAS_VULKAN
        gfxvk::stutter::trace().flush();
        if (render::active() == render::Api::Vulkan) gx2::checkpoint_vulkan_caches();
#endif
        if (FILE* f = fopen("test_done", "w")) fclose(f);
    }
    // Opt-in raw controller fixture: exercise bindings and the dead zone before guest delivery.
    static const bool controller_stick = getenv("WWHD_TEST_CONTROLLER_STICK") != nullptr;
    for (auto& p : sc.sticks)
        if (t >= p.from && t < p.to) {
            s.lx = p.x; s.ly = p.y;
            if (controller_stick) {
                float values[input_map::kPadCount]{};
                values[p.x < 0 ? input_map::kPadLSLeft : input_map::kPadLSRight] = std::fabs(p.x);
                values[p.y < 0 ? input_map::kPadLSDown : input_map::kPadLSUp] = std::fabs(p.y);
                auto mapped = input_map::controller_state(input_map::current(), values);
                s.lx = mapped.lx; s.ly = mapped.ly;
            }
        }
    for (auto& p : sc.rsticks)
        if (t >= p.from && t < p.to) { s.rx = p.x; s.ry = p.y; }
    uint32_t timed_buttons = 0;
    bool runtime_move = false;
    for (auto& p : sc.presses)
        if (t >= p.from && t < p.to) timed_buttons |= p.bits;
#ifdef WWHD_IOS
    if (ios::runtime_test_enabled()) {
        const uint32_t play = GD(0x1046F0B0), link = ld32(play + 0x5B34);
        char stage[9]{}; memcpy(stage, mem::ptr(play + 0x5134), 8);
        runtime_move = ios::runtime_test_script_input(s, timed_buttons, stage, ld8(play + 0x5292),
            link >= mem::kMem2Start && link <= mem::kMem2End - 4 && !(link & 3), CACurrentMediaTime());
    } else
#endif
        s.buttons |= timed_buttons;
    static std::vector<TimedStick> touches = [] {
        std::vector<TimedStick> v;
        const char* e = getenv("WWHD_TEST_TOUCH");
        double a, b; float x, y; int n;
        while (e && sscanf(e, "%lf-%lf:%f:%f%n", &a, &b, &x, &y, &n) == 4) {
            v.push_back({a, b, x, y});
            e += n;
            if (*e != ',') break;
            e++;
        }
        return v;
    }();
    g_test_touch = false;
    for (auto& p : touches)
        if (t >= p.from && t < p.to) g_test_touch = true, g_test_tx = p.x, g_test_ty = p.y;
    return runtime_move;
}

static std::atomic<bool> g_pro{getenv("WWHD_PRO_CONTROLLER") != nullptr};
bool pro_controller() { return g_pro.load(std::memory_order_relaxed); }
static std::atomic<void (*)(bool)> g_controller_listener{nullptr};
void set_controller_listener(void (*fn)(bool pro)) { g_controller_listener = fn; }
void set_pro_controller(bool on) {
    const bool was = g_pro.exchange(on);
    LOG("[input] keyboard/controller act as %s", on ? "Pro Controller" : "GamePad");
    if (was != on)
        if (auto fn = g_controller_listener.load()) fn(on);
}

PadState read() {
    static const std::vector<Press> script = scripted();
    static const std::vector<Stick> sticks = scripted_stick();
    static const std::vector<KeyPress> keys = scripted_keys();
    static const std::vector<Stick> rsticks = scripted_stick("WWHD_RSTICK");
    std::lock_guard<std::mutex> lk(g_mu);
    // debug: WWHD_NO_HOST_INPUT=1 ignores keyboard and host controllers (scripted test runs)
    static const bool no_host = getenv("WWHD_NO_HOST_INPUT") != nullptr;
    if (!keys.empty()) {
        memset(g_script_keys, 0, sizeof g_script_keys);
        for (auto& p : keys)
            if (render::frame_count() >= p.from && render::frame_count() <= p.to)
                for (int c : p.codes) if (c < 256) g_script_keys[c] = true;
    }
    PadState k = keyboard_state(!no_host), s = g_pad;
    if (no_host) s = PadState{};
#ifdef WWHD_IOS
    if (!no_host) ios::touch::merge(s,g_touch_pad);
#endif
    for (auto& p : script)
        if (render::frame_count() >= p.from && render::frame_count() <= p.to) s.buttons |= p.bits;
    for (auto& p : sticks)
        if (render::frame_count() >= p.from && render::frame_count() <= p.to) { s.lx = p.x; s.ly = p.y; }
    for (auto& p : rsticks)
        if (render::frame_count() >= p.from && render::frame_count() <= p.to) { s.rx = p.x; s.ry = p.y; }
    [[maybe_unused]] const bool runtime_move = apply_scenario(s);
    s.buttons |= k.buttons;
    if (k.lx || k.ly) { s.lx = k.lx; s.ly = k.ly; }
    if (k.rx || k.ry) { s.rx = k.rx; s.ry = k.ry; }
    s.touch = g_touch;
    s.tx = g_tx;
    s.ty = g_ty;
    if (g_test_touch) s.touch = true, s.tx = g_test_tx, s.ty = g_test_ty;
    // debug: WWHD_LOG_BUTTONS=1 logs every change of the merged button bits
    static const bool log_buttons = getenv("WWHD_LOG_BUTTONS") != nullptr;
    static uint32_t last_buttons = 0;
    if (log_buttons && s.buttons != last_buttons) {
        LOG("[input] frame %llu buttons %04X", (unsigned long long)render::frame_count(), s.buttons);
        last_buttons = s.buttons;
    }
    mods::filter_pad(s);  // gameplay mods: mouse camera, wheel -> R3
    if (overlay::blocks_input()) s = PadState{};  // the settings overlay has the input
#ifdef WWHD_IOS
    static bool release_after_panel=false;
    if(ios::controls_block_input()) { release_after_panel=true; s={}; }
    else if(release_after_panel) {
        if(!s.buttons && std::abs(s.lx)<.2f && std::abs(s.ly)<.2f && std::abs(s.rx)<.2f && std::abs(s.ry)<.2f)
            release_after_panel=false;
        s={};
    }
    if (ios::runtime_test_enabled()) {
        static bool move_started = false, move_ended = false;
        static double move_origin = 0;
        if ((runtime_move && !move_started) || (move_started && !move_ended && !runtime_move)) {
            const bool starting = !move_started;
            if (starting) { move_started = true; move_origin = ios::runtime_test_move_start.load(); }
            else move_ended = true;
            // Final host state after keyboard/mod/UI filtering; KPAD delivery needs its own trace.
            LOG("[ios-runtime-test] host injected move %s phaseElapsed=%.6f pro=%u hostPadLx=%.3f hostPadLy=%.3f",
                starting ? "start" : "end", CACurrentMediaTime() - move_origin,
                unsigned(pro_controller()), s.lx, s.ly);
        }
    }
#endif
    return s;
}

void prompt_text(const std::u16string& initial, int max_len,
                 std::function<void(bool ok, std::u16string text)> done) {
#ifdef WWHD_IOS
    ios::prompt_text(initial, max_len, done);
#else
    NSString* init = [NSString stringWithCharacters:(const unichar*)initial.data() length:initial.size()];
    dispatch_async(dispatch_get_main_queue(), ^{
        {
            std::lock_guard<std::mutex> lk(g_mu);
            g_mouse_bindings.consume();
            memset(g_keys, 0, sizeof(g_keys));  // keys pressed now belong to the prompt
        }
        NSAlert* alert = [[NSAlert alloc] init];
        alert.messageText = @"Enter text";
        alert.informativeText = [NSString stringWithFormat:@"Up to %d characters.", max_len];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        NSTextField* field = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 0, 260, 24)];
        field.stringValue = init;
        alert.accessoryView = field;
        alert.window.initialFirstResponder = field;
        auto finish = [done, max_len, field](NSModalResponse r) {
            NSString* t = field.stringValue;
            std::u16string out(t.length, u'\0');
            [t getCharacters:(unichar*)out.data() range:NSMakeRange(0, t.length)];
            if ((int)out.size() > max_len) out.resize(max_len);
            done(r == NSAlertFirstButtonReturn, out);
        };
        NSWindow* parent = NSApp.mainWindow ?: NSApp.windows.firstObject;
        if (parent) [alert beginSheetModalForWindow:parent completionHandler:^(NSModalResponse r) { finish(r); }];
        else finish([alert runModal]);
    });
#endif
}

}  // namespace input

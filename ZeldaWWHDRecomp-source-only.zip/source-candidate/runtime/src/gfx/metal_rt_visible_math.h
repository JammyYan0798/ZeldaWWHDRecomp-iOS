#pragma once
#include "metal_rt_capture.h"
namespace gfx::ray_scene {
struct alignas(16) F4 { float x=0,y=0,z=0,w=0; };
struct alignas(16) U4 { uint32_t x=0,y=0,z=0,w=0; };
struct Params {
    F4 view[3], projection[4], inverseProjection[4], eye, viewport, zrange;
    U4 sizes;
};
static_assert(sizeof(Params)==240);
inline bool parameters(const rt_capture::Sea& sea,bool halfZ,Params& p) {
    std::array<double,16> inv{};
    if(!rt_capture::inverse(sea.projection,halfZ,inv))return false;
    for(int r=0;r<3;++r)p.view[r]={sea.view[4*r],sea.view[4*r+1],sea.view[4*r+2],sea.view[4*r+3]};
    for(int r=0;r<4;++r) {
        p.projection[r]={sea.projection[4*r],sea.projection[4*r+1],sea.projection[4*r+2],sea.projection[4*r+3]};
        p.inverseProjection[r]={float(inv[4*r]),float(inv[4*r+1]),float(inv[4*r+2]),float(inv[4*r+3])};
    }
    p.eye={sea.eye[0],sea.eye[1],sea.eye[2],1}; p.zrange.z=halfZ?1:0;
    return true;
}
} // namespace gfx::ray_scene

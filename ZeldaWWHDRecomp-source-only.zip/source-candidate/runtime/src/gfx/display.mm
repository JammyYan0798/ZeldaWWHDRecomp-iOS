#include "metal_upscale.h"
// Display: the TV and GamePad windows, full screen, and the final composition of the TV and GamePad
// images onto the screen (scale to fit with letterbox/pillarbox, scaling filter, GamePad screen as a
// separate window or as a picture-in-picture overlay inside the TV window).
//
// Everything here only decides how the finished scan-out images (R.tv.tex, R.drc.tex, any size and
// aspect) are put on the screen; what the game renders is decided elsewhere.
//
// Both renderers use these windows (renderer.h): Metal draws the composition below; Vulkan
// (gfx/vulkan, MoltenVK) gets each view's CAMetalLayer for a VK_EXT_metal_surface swapchain and asks
// display_plan() for the same layout (picture rectangles, GamePad overlay, scaling filter).
//
// Shortcuts: Cmd+F (or Ctrl+Cmd+F, or the green button) full screen; Cmd+G show/hide the GamePad screen.
// Closing the TV window (close button, Cmd+W) quits the app, asking first while a game is in progress
// (quit_prompt.mm); closing the GamePad window only hides it.
// The Display menu holds the rest. Choices are kept in ~/Library/Application Support/wwhd/display.plist
// (test runs with WWHD_NO_HOST_INPUT neither read nor write it unless WWHD_DISPLAY_SETTINGS names a file).
//
// The modes, the layout of the TV window, the automatic overlay and the overlay's touch mapping are
// shared with the SDL host (display_modes.cpp, which lists their test variables: WWHD_DRC_MODE,
// WWHD_DRC_PIP, WWHD_SCALE_FILTER, WWHD_SIM_SCREEN, WWHD_TEST_TOUCH).
//
// Debug / test environment:
//   WWHD_FULLSCREEN=0|1                  TV window starts windowed / in full screen instead of as it was left
//                                        (that session's full screen is not saved; 1 takes over the screen!)
//   WWHD_DUMP_PRESENT=1                  with WWHD_DUMP_FRAMES: also write frame_<n>_present.png (the composed
//                                        TV window) and frame_<n>_present_drc.png (GamePad window, window mode)
//   WWHD_TEST_DRC_KEY=3500,3700          frames at which Cmd+G (show/hide GamePad screen) is simulated
//   WWHD_HIDDEN_WINDOWS=1                test runs: the windows are never put on screen (nothing pops up;
//                                        frame / present dumps still work, the drawables are not presented)
#import <AppKit/AppKit.h>
#import <QuartzCore/QuartzCore.h>

#include "../exception_report.h"
#include <atomic>
#include <cmath>
#include <map>
#include <mutex>
#include <string>
#include <tuple>
#include <vector>

#include "../aspect.h"
#include "display.h"
#include "display_modes.h"
#include "headless_compose.h"
#include "gx2/gx2.h"
#include "input.h"
#include "metal.h"
#include "renderer.h"
#include "runtime.h"
#include "../interp.h"
#ifdef WWHD_HAS_VULKAN
#include "vulkan/api.h"
#endif
#include "imgui.h"
#include "backends/imgui_impl_metal.h"
#include "../overlay/overlay.h"
#include "../overlay/guest_hud.h"
#include "../screenshot.h"

// The game's own icon in the Dock: meta/iconTex.tga of the game folder (uncompressed 32-bit TGA,
// 128x128 in Wind Waker HD), as the SDL host does for its windows. Nothing happens without it.
static void set_dock_icon() {
    NSData* data = [NSData dataWithContentsOfFile:@((config::game_dir + "/meta/iconTex.tga").c_str())];
    const uint8_t* d = (const uint8_t*)data.bytes;
    if (data.length < 18 || d[1] != 0 || d[2] != 2 || d[16] != 32) return;  // no colour map, true colour, 32 bpp
    const NSInteger w = d[12] | d[13] << 8, h = d[14] | d[15] << 8, start = 18 + d[0];
    if (!w || !h || w > 1024 || h > 1024 || (NSInteger)data.length < start + w * h * 4) return;
    NSBitmapImageRep* rep = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:nullptr pixelsWide:w pixelsHigh:h
        bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace
        bitmapFormat:NSBitmapFormatAlphaNonpremultiplied bytesPerRow:w * 4 bitsPerPixel:32];
    if (!rep) return;
    const bool topDown = d[17] & 0x20;  // otherwise the first row is the bottom one
    for (NSInteger y = 0; y < h; y++) {
        const uint8_t* src = d + start + (topDown ? y : h - 1 - y) * w * 4;
        uint8_t* dst = rep.bitmapData + y * rep.bytesPerRow;
        for (NSInteger x = 0; x < w; x++) {  // BGRA -> RGBA
            dst[x * 4] = src[x * 4 + 2]; dst[x * 4 + 1] = src[x * 4 + 1];
            dst[x * 4 + 2] = src[x * 4]; dst[x * 4 + 3] = src[x * 4 + 3];
        }
    }
    NSImage* image = [[NSImage alloc] initWithSize:NSMakeSize(w, h)];
    [image addRepresentation:rep];
    NSApp.applicationIconImage = image;
}

namespace mods { bool mouse_captured(); }

namespace gfx {
extern Renderer R;
void install_menu(NSWindow* tv);  // menu.mm
Class tv_window_class();           // quit_prompt.mm: closing the TV window quits (after asking)
void install_quit_prompt(NSWindow* tv);
bool fxaa_enabled();
void dump_texture(id<MTLTexture> src, const char* name, bool async, bool srgbEncode);

// ---------------------------------------------------------------- options
// (the option state itself: display_modes.cpp)
static int find_name(const char* const* names, int n, NSString* s, int def) {
    return find_name(names, n, [s isKindOfClass:[NSString class]] ? s.UTF8String : nullptr, def);
}
static bool hidden_windows() {
    static const bool h = [] { const char* e = getenv("WWHD_HIDDEN_WINDOWS"); return e && *e && strcmp(e, "0"); }();
    return h;
}

// ---------------------------------------------------------------- settings file
static NSMutableDictionary* g_settings;
static NSString* settings_path() {
    if (const char* e = getenv("WWHD_DISPLAY_SETTINGS")) return @(e);
    if (getenv("WWHD_NO_HOST_INPUT")) return nil;  // test runs leave the user's choices alone
    return [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/wwhd/display.plist"];
}
static void load_settings() {
    NSString* p = settings_path();
    g_settings = p ? [[NSDictionary dictionaryWithContentsOfFile:p] mutableCopy] : nil;
    if (!g_settings) g_settings = [NSMutableDictionary new];
}
static void save_settings() {
    NSString* p = settings_path();
    if (!p) return;
    [[NSFileManager defaultManager] createDirectoryAtPath:[p stringByDeletingLastPathComponent]
                              withIntermediateDirectories:YES attributes:nil error:nil];
    [g_settings writeToFile:p atomically:YES];
}
static void set_setting(NSString* key, id value) {
    if (!g_settings) load_settings();
    if (value) g_settings[key] = value;
    else [g_settings removeObjectForKey:key];
    save_settings();
}
// renderer.cpp: the renderer choice lives in the same file (read before the windows exist)
bool host_setting(const char* key, std::string& value) {
    if (!g_settings) load_settings();
    id v = g_settings[@(key)];
    if (![v isKindOfClass:[NSString class]]) return false;
    value = ((NSString*)v).UTF8String;
    return true;
}
void set_host_setting(const char* key, const std::string& value) { set_setting(@(key), @(value.c_str())); }
static void save_options() {
    g_settings[@"drcMode"] = @(kModeNames[display_saved_mode()]);
    g_settings[@"pipCorner"] = @(kCornerNames[g_corner]);
    g_settings[@"pipSize"] = @(g_pip_size.load());
    g_settings[@"pipOpacity"] = @(g_pip_opacity.load());
    g_settings[@"scaleFilter"] = @(kFilterNames[g_filter]);
    save_settings();
}
static void load_options() {
    g_mode = find_name(kModeNames, kDrcModeCount, g_settings[@"drcMode"], kDrcWindow);
    if (!drc_mode_offered(g_mode)) g_mode = kDrcWindow;
    g_corner = find_name(kCornerNames, 4, g_settings[@"pipCorner"], 3);
    g_filter = find_name(kFilterNames, 3, g_settings[@"scaleFilter"], kSmooth);
    if (NSNumber* n = g_settings[@"pipSize"]) g_pip_size = std::clamp(n.floatValue, 0.1f, 0.5f);
    if (NSNumber* n = g_settings[@"pipOpacity"]) g_pip_opacity = std::clamp(n.floatValue, 0.2f, 1.0f);
    display_env_overrides();  // start-up overrides for tests (not saved)
}

}  // namespace gfx

// ---------------------------------------------------------------- views
// GamePad window: the mouse stands in for the touch panel
@interface WWDrcView : NSView
@end
@implementation WWDrcView
- (BOOL)acceptsFirstMouse:(NSEvent*)e { return YES; }
- (void)touch:(NSEvent*)e down:(bool)down {
    NSPoint p = [self convertPoint:e.locationInWindow fromView:nil];
    NSSize sz = self.bounds.size;
    // the image is letterboxed to its aspect inside the view
    float a = gfx::g_drc_aspect;
    float w = sz.width, h = sz.height, x0 = 0, y0 = 0;
    if (w / h > a) { x0 = (w - h * a) / 2; w = h * a; } else { y0 = (h - w / a) / 2; h = w / a; }
    float x = (p.x - x0) / w, y = 1.0f - (p.y - y0) / h;
    input::set_touch(down, std::clamp(x, 0.0f, 1.0f), std::clamp(y, 0.0f, 1.0f));
}
- (void)mouseDown:(NSEvent*)e { [self touch:e down:true]; }
- (void)mouseDragged:(NSEvent*)e { [self touch:e down:true]; }
- (void)mouseUp:(NSEvent*)e { [self touch:e down:false]; }
@end

// TV window: clicks on the GamePad overlay are touches
@interface WWTvView : NSView
@property bool touching;
@end
@implementation WWTvView
- (bool)map:(NSEvent*)e x:(float*)tx y:(float*)ty clamp:(bool)c {
    NSPoint p = [self convertPoint:e.locationInWindow fromView:nil];
    NSSize sz = self.bounds.size;
    if (sz.width <= 0 || sz.height <= 0) return false;
    return gfx::overlay_hit(p.x / sz.width, 1.0f - p.y / sz.height, tx, ty, c);
}
- (BOOL)acceptsFirstMouse:(NSEvent*)e {
    float x, y;
    return [self map:e x:&x y:&y clamp:false];
}
- (void)mouseDown:(NSEvent*)e {
    float x, y;
    if ([self map:e x:&x y:&y clamp:false]) {
        self.touching = true;
        input::set_touch(true, x, y);
    } else {
        [super mouseDown:e];
    }
}
- (void)mouseDragged:(NSEvent*)e {
    float x, y;
    if (self.touching && [self map:e x:&x y:&y clamp:true]) input::set_touch(true, x, y);
}
- (void)mouseUp:(NSEvent*)e {
    float x, y;
    if (!self.touching) return;
    self.touching = false;
    if (![self map:e x:&x y:&y clamp:true]) x = y = 0;
    input::set_touch(false, x, y);
}
@end

namespace gfx {

// ---------------------------------------------------------------- windows
static NSWindow* g_tv_window = nil;
static NSWindow* g_drc_window = nil;
static NSRect g_tv_normal_frame, g_drc_normal_frame;  // frames outside full screen, for saving

static bool is_fullscreen(NSWindow* w) { return w && (w.styleMask & NSWindowStyleMaskFullScreen); }
bool tv_fullscreen() { return is_fullscreen(g_tv_window); }

// a saved frame is used only if it still fits a connected screen well enough
static bool frame_usable(NSRect f) {
    if (f.size.width < 200 || f.size.height < 120) return false;
    for (NSScreen* s in NSScreen.screens) {
        NSRect v = s.visibleFrame, i = NSIntersectionRect(v, f);
        if (i.size.width * i.size.height >= 0.5 * f.size.width * f.size.height && f.size.width <= v.size.width + 1 &&
            f.size.height <= v.size.height + 1 && NSMaxY(f) <= NSMaxY(v) + 1)  // title bar reachable
            return true;
    }
    return false;
}

static NSScreen* screen_named(NSString* name) {
    if (!name) return nil;
    for (NSScreen* s in NSScreen.screens)
        if ([s.localizedName isEqualToString:name]) return s;
    return nil;
}

static void update_drawable_size(CAMetalLayer* layer, NSWindow* win) {
    if (!layer) return;
    NSView* view = win.contentView;
    layer.contentsScale = win.backingScaleFactor;  // Retina: present at the display's pixel density
    NSSize sz = view.bounds.size;
    layer.drawableSize = CGSizeMake(std::max(1.0, sz.width * layer.contentsScale), std::max(1.0, sz.height * layer.contentsScale));
}

// the layer each window's view presents to (index 0 TV, 1 GamePad); made by the renderer that starts
static CAMetalLayer* g_layers[2];
static NSWindow* g_windows[2];
static bool screen_visible(NSWindow* win) { return (win.occlusionState & NSWindowOcclusionStateVisible) != 0; }
// a window was resized, moved to another screen or (un)covered: tell the renderer
// The TV window's screen refresh rate for frame interpolation (interp::output_fps caps 120/240 fps to
// it): NSScreen.maximumFramesPerSecond, 120 on ProMotion displays (whose CAMetalLayers present at up
// to 120 Hz), 60 on most external ones. Main thread; again whenever the window changes screens.
static void report_refresh_rate(NSWindow* win) {
    NSScreen* sc = win.screen ?: NSScreen.mainScreen;
    int hz = 0;
    if (@available(macOS 12.0, *)) hz = sc ? (int)sc.maximumFramesPerSecond : 0;
    interp::set_display_hz(hz);
}

static void screen_changed(int i) {
    NSWindow* win = g_windows[i];
    if (win && i == 0) report_refresh_rate(win);
    if (!win || !g_layers[i]) return;
    update_drawable_size(g_layers[i], win);
    if (render::active() == render::Api::Metal) {
        Screen& scr = i ? R.drc : R.tv;
        scr.visible = screen_visible(win);
    }
#ifdef WWHD_HAS_VULKAN
    else gfxvk::screen_changed(i, screen_visible(win));
#endif
}

static NSWindow* make_window(int index, NSString* title, NSView* view, int w, int h, NSPoint origin) {
    Class cls = index == 0 ? tv_window_class() : [NSWindow class];
    NSWindow* win = [[cls alloc] initWithContentRect:NSMakeRect(origin.x, origin.y, w, h)
                                                styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable |
                                                          NSWindowStyleMaskResizable | NSWindowStyleMaskMiniaturizable
                                                  backing:NSBackingStoreBuffered
                                                    defer:NO];
    [win setTitle:title];
    win.collectionBehavior |= NSWindowCollectionBehaviorFullScreenPrimary;  // green button, Ctrl+Cmd+F
    win.backgroundColor = NSColor.blackColor;
    if (view) [win setContentView:view];
    view = [win contentView];
    [view setWantsLayer:YES];
    g_windows[index] = win;
    if (index == 0) report_refresh_rate(win);
    for (NSNotificationName n in @[ NSWindowDidChangeOcclusionStateNotification, NSWindowDidResizeNotification,
                                    NSWindowDidChangeBackingPropertiesNotification, NSWindowDidChangeScreenNotification ])
        [[NSNotificationCenter defaultCenter] addObserverForName:n object:win queue:nil usingBlock:^(NSNotification*) {
            screen_changed(index);
        }];
    return win;
}

// a fresh CAMetalLayer on a window's view (the renderer's presentation target)
static CAMetalLayer* attach_layer(int i) {
    NSWindow* win = g_windows[i];
    if (!win) return nil;
    CAMetalLayer* layer = [CAMetalLayer layer];
    layer.backgroundColor = CGColorGetConstantColor(kCGColorBlack);
    [win.contentView setLayer:layer];
    g_layers[i] = layer;
    update_drawable_size(layer, win);
    return layer;
}

// Metal: the layers present the composition below (present_screens)
static void attach_metal_layers() {
    for (int i = 0; i < 2; i++) {
        Screen& scr = i ? R.drc : R.tv;
        CAMetalLayer* layer = attach_layer(i);
        scr.layer = layer;
        if (!layer) continue;
        // The final SDR drawable contains sRGB colors. Let Core Animation match them to
        // the monitor's profile, as MoltenVK does for VK_COLOR_SPACE_SRGB_NONLINEAR_KHR.
        CGColorSpaceRef outputColorSpace = CGColorSpaceCreateWithName(kCGColorSpaceSRGB);
        layer.colorspace = outputColorSpace;
        CGColorSpaceRelease(outputColorSpace);
        layer.device = R.device;
        layer.pixelFormat = MTLPixelFormatBGRA8Unorm;
        layer.framebufferOnly = YES;
        layer.maximumDrawableCount = 3;
        if (hidden_windows()) scr.visible = false;  // never on screen: no drawables
    }
}

// remember frames (outside full screen) and full-screen state (fsKey nil: not remembered)
static void track_window(NSWindow* win, NSRect* normal, NSString* frameKey, NSString* fsKey) {
    *normal = win.frame;
    auto save_frame = ^(NSNotification*) {
        if (is_fullscreen(win) || win.inLiveResize) return;
        *normal = win.frame;
        set_setting(frameKey, NSStringFromRect(*normal));
    };
    for (NSNotificationName n in @[ NSWindowDidMoveNotification, NSWindowDidEndLiveResizeNotification ])
        [[NSNotificationCenter defaultCenter] addObserverForName:n object:win queue:nil usingBlock:save_frame];
    [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowWillEnterFullScreenNotification object:win queue:nil
                                                  usingBlock:^(NSNotification*) {
        set_setting(frameKey, NSStringFromRect(*normal));
        if (fsKey) set_setting(fsKey, @YES);
    }];
    if (fsKey)
        [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowDidExitFullScreenNotification object:win queue:nil
                                                      usingBlock:^(NSNotification*) { set_setting(fsKey, @NO); }];
}

// show or hide the GamePad window to match the mode (main thread)
static void apply_drc_window() {
    if (!g_drc_window) return;
    if (drc_window_wanted()) {
        // never takes the keyboard; test runs stay behind the user's windows
        if (hidden_windows()) return;
        if (!g_drc_window.visible) {
            if (getenv("WWHD_NO_HOST_INPUT")) [g_drc_window orderBack:nil];
            else [g_drc_window orderFront:nil];
        }
    } else if (g_drc_window.visible) {
        if (is_fullscreen(g_drc_window)) [g_drc_window toggleFullScreen:nil];  // hidden after the transition
        else [g_drc_window orderOut:nil];
    }
}

// GamePad window, shown/hidden from the Input menu (the game keeps rendering its image either way)
bool drc_window_available() { return g_drc_window != nil || g_mode == kDrcPip || g_mode == kDrcAuto; }
bool drc_window_shown() { return drc_screen_shown(g_drc_window.visible); }
// Show / hide the GamePad screen in the current mode (Cmd+G, Input menu, Pro Controller choice)
void show_drc_window(bool on) {
    auto apply = [on] {
        display_show_drc(on);
        apply_drc_window();
        LOG("[display] GamePad screen %s (%s)", on ? "shown" : "hidden", kModeNames[g_mode]);
    };
    if ([NSThread isMainThread]) apply();
    else dispatch_async(dispatch_get_main_queue(), ^{ apply(); });
}
void toggle_drc_screen() { show_drc_window(!drc_window_shown()); }

void set_drc_mode(int m) {
    display_set_mode(m);
    apply_drc_window();
    save_options();
    LOG("[display] GamePad screen mode: %s", kModeNames[m]);
}

static void move_drc_to_screen(NSScreen* s) {
    if (!g_drc_window || !s) return;
    if (is_fullscreen(g_drc_window)) return;  // leave full screen first
    NSRect v = s.visibleFrame, f = g_drc_window.frame;
    f.size.width = std::min(f.size.width, v.size.width);
    f.size.height = std::min(f.size.height, v.size.height);
    f.origin = NSMakePoint(NSMidX(v) - f.size.width / 2, NSMidY(v) - f.size.height / 2);
    [g_drc_window setFrame:f display:YES];
    set_setting(@"drcScreen", s.localizedName);
}

static void create_windows() {
    static bool done = false;  // once, whichever renderer starts (a failed Vulkan start falls back to Metal)
    if (done) return;
    done = true;
    [NSApplication sharedApplication];
    // a game: no App Nap / timer coalescing, even when the window is in the background
    static id activity = [[NSProcessInfo processInfo]
        beginActivityWithOptions:NSActivityUserInitiated | NSActivityLatencyCritical | NSActivityIdleDisplaySleepDisabled
                          reason:@"game running"];
    (void)activity;
    // scripted test runs (WWHD_NO_HOST_INPUT) run as a background app: no Dock icon, never takes the
    // keyboard focus from the user's game
    bool test = getenv("WWHD_NO_HOST_INPUT") != nullptr;
    [NSApp setActivationPolicy:test ? NSApplicationActivationPolicyAccessory : NSApplicationActivationPolicyRegular];
    if (!test) set_dock_icon();
    load_settings();
    load_options();
    NSWindow* tv = make_window(0, @"The Legend of Zelda: The Wind Waker HD (recompiled)",
                               [[WWTvView alloc] initWithFrame:NSMakeRect(0, 0, 1280, 720)], 1280, 720, NSMakePoint(0, 0));
    g_tv_window = tv;
    install_menu(tv);
    install_quit_prompt(tv);
    NSRect saved = NSRectFromString(g_settings[@"tvFrame"] ?: @"");
    if (frame_usable(saved)) [tv setFrame:saved display:NO];
    else [tv center];
    // full screen as left (a WWHD_FULLSCREEN start leaves the saved state alone)
    track_window(tv, &g_tv_normal_frame, @"tvFrame", display_fullscreen_env() ? nil : @"tvFullScreen");
    if (!getenv("WWHD_NO_GAMEPAD")) {
        // GamePad screen to the right of the TV window (or where it was last)
        NSRect f = tv.frame;
        NSWindow* drc = make_window(1, @"GamePad", [[WWDrcView alloc] initWithFrame:NSMakeRect(0, 0, 427, 240)], 427, 240,
                                    NSMakePoint(NSMaxX(f) + 8, NSMinY(f)));
        g_drc_window = drc;
        g_has_drc_window = true;
        drc.releasedWhenClosed = NO;  // closing only hides it; the Input / Display menu can bring it back
        NSRect ds = NSRectFromString(g_settings[@"drcFrame"] ?: @"");
        NSScreen* want = screen_named(g_settings[@"drcScreen"]);
        if (frame_usable(ds)) [drc setFrame:ds display:NO];
        else if (want) move_drc_to_screen(want);
        track_window(drc, &g_drc_normal_frame, @"drcFrame", @"drcFullScreen");
        [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowWillCloseNotification object:drc queue:nil
                                                      usingBlock:^(NSNotification*) { if (g_mode == kDrcWindow) g_shown = false; }];
        [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowDidExitFullScreenNotification object:drc queue:nil
                                                      usingBlock:^(NSNotification*) {
            dispatch_async(dispatch_get_main_queue(), ^{ apply_drc_window(); });  // left full screen to hide
        }];
        [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowDidMoveNotification object:drc queue:nil
                                                      usingBlock:^(NSNotification*) {
            if (drc.screen && !is_fullscreen(drc)) g_settings[@"drcScreen"] = drc.screen.localizedName;
        }];
    }
    g_shown = !input::pro_controller();  // Pro Controller: GamePad screen starts hidden
    apply_drc_window();
    if (hidden_windows()) {
        // test run: never on screen
    } else if (test) {
        [tv orderBack:nil];  // scripted test run: stay behind, don't take focus
    } else {
        [tv makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];
    }
    // full screen as last time (display_modes.cpp: never in test runs unless asked for, never with hidden windows)
    if (display_start_fullscreen([g_settings[@"tvFullScreen"] boolValue], hidden_windows()))
        dispatch_async(dispatch_get_main_queue(), ^{ if (!is_fullscreen(tv)) [tv toggleFullScreen:nil]; });
    if (!test && g_drc_window && drc_window_wanted() && [g_settings[@"drcFullScreen"] boolValue] &&
        screen_named(g_settings[@"drcScreen"]) && screen_named(g_settings[@"drcScreen"]) != tv.screen)
        dispatch_async(dispatch_get_main_queue(), ^{ if (!is_fullscreen(g_drc_window)) [g_drc_window toggleFullScreen:nil]; });

    // hide the pointer after 2 s without movement while the game window is active, in a window too
    // (issue #109); not while the settings overlay is open or the mouse camera holds it
    [NSTimer scheduledTimerWithTimeInterval:0.25 repeats:YES block:^(NSTimer*) {
        static NSPoint last = {-1, -1};
        static double moved = 0;
        static bool hidden = false;
        NSPoint p = [NSEvent mouseLocation];
        if (!NSEqualPoints(p, last)) { last = p; moved = display_now(); hidden = false; }
        if (!hidden && NSApp.active && g_tv_window.keyWindow && !mods::mouse_captured() && !overlay::is_open() &&
            display_now() - moved > 2.0) {
            [NSCursor setHiddenUntilMouseMoves:YES];
            hidden = true;
        }
    }];
    // debug: WWHD_TEST_DRC_MODE (display_modes.cpp) switches the mode as the Display menu does
    if (getenv("WWHD_TEST_DRC_MODE"))
        [NSTimer scheduledTimerWithTimeInterval:1.0 / 120 repeats:YES block:^(NSTimer*) {
            const int m = display_test_mode(render::frame_count());
            if (m >= 0) set_drc_mode(m);
        }];
    // debug: simulated Cmd+G presses
    if (const char* e = getenv("WWHD_TEST_DRC_KEY")) {
        static std::vector<uint64_t> frames;
        for (const char* p = e; *p;) {
            frames.push_back(strtoull(p, (char**)&p, 10));
            while (*p == ',') p++;
        }
        [NSTimer scheduledTimerWithTimeInterval:1.0 / 120 repeats:YES block:^(NSTimer*) {
            static size_t i = 0;
            // the active renderer's frames (gfx::frame_count is the Metal renderer's: 0 with Vulkan)
            if (i < frames.size() && render::frame_count() >= frames[i]) {
                i++;
                LOG("[display] test: Cmd+G at frame %llu", (unsigned long long)render::frame_count());
                toggle_drc_screen();
            }
        }];
    }
}

#include "metal_present.inc"

// keyboard events and controller polling, after AppKit/window setup (once)
void display_start_input() {
    static bool done = false;
    if (done) return;
    done = true;
    input::init();
}

// Metal renderer start-up (metal_main.mm)
void display_init() {
    create_windows();
    attach_metal_layers();
    display_start_input();
    create_present_pipeline();
}

// Vulkan renderer start-up (gfx/vulkan/backend_table.cpp): windows, then a layer per view for its
// VK_EXT_metal_surface; display_detach() takes them away again if Vulkan cannot start
void display_create_windows() { create_windows(); }
void display_attach_vulkan(void** tv, void** drc) {
    *tv = (__bridge void*)attach_layer(0);
    *drc = (__bridge void*)attach_layer(1);
}
// after the Vulkan renderer started: windows that are never shown get no presentation
void display_vulkan_started() {
#ifdef WWHD_HAS_VULKAN
    if (hidden_windows())
        for (int i = 0; i < 2; i++) gfxvk::screen_changed(i, false);
#endif
}
void display_detach() {
    for (int i = 0; i < 2; i++) {
        if (g_windows[i]) [g_windows[i].contentView setLayer:nil];
        g_layers[i] = nil;
    }
}
CAMetalLayer* display_layer(int i) { return g_layers[i]; }

// the main thread's event loop, for either renderer
void run_appkit_loop() {
    // orderly exit (Quit, Cmd+Q): the renderer writes its caches (Vulkan pipeline / SPIR-V caches)
    [[NSNotificationCenter defaultCenter] addObserverForName:NSApplicationWillTerminateNotification object:nil queue:nil
                                                  usingBlock:^(NSNotification*) {
        render::shutdown();
        // leave without running static destructors: the GX2 render thread and the game threads may
        // still be using them (exit() here crashed in the renderer's caches, Metal and Vulkan alike)
        fflush(stdout);
        fflush(stderr);
        std::_Exit(0);
    }];
    // test runs: WWHD_EXIT_AT_FRAME=n quits (orderly) once the renderer reached frame n
    if (const char* e = getenv("WWHD_EXIT_AT_FRAME")) {
        uint64_t at = strtoull(e, nullptr, 10);
        if (at)
            [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer* t) {
                if (render::frame_count() < at) return;
                [t invalidate];
                LOG("[display] WWHD_EXIT_AT_FRAME: quitting at frame %llu", (unsigned long long)render::frame_count());
                [NSApp terminate:nil];
            }];
    }
    // test runs: WWHD_TEST_RENDERER_SWITCH=frame:metal|vulkan does what Graphics > Renderer > Restart Now does
    if (const char* e = getenv("WWHD_TEST_RENDERER_SWITCH")) {
        uint64_t at = strtoull(e, nullptr, 10);
        const char* c = strchr(e, ':');
        render::Api a = c && !strcasecmp(c + 1, "vulkan") ? render::Api::Vulkan : render::Api::Metal;
        [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer* t) {
            if (render::frame_count() < at) return;
            [t invalidate];
            LOG("[display] test: renderer %s, restart at frame %llu", render::api_name(a), (unsigned long long)render::frame_count());
            unsetenv("WWHD_TEST_RENDERER_SWITCH");  // once
            render::set_preferred(a);
            render::restart();
        }];
    }
    [NSApp run];
}

// a message on the TV window that does not stop the game (renderer fallback); test runs only log it
void show_startup_notice(const std::string& title, const std::string& text) {
    LOG("[display] %s: %s", title.c_str(), text.c_str());
    if (getenv("WWHD_NO_HOST_INPUT")) return;
    NSString* t = @(title.c_str()), *m = @(text.c_str());
    dispatch_async(dispatch_get_main_queue(), ^{
        NSAlert* a = [NSAlert new];
        a.messageText = t;
        a.informativeText = m;
        a.alertStyle = NSAlertStyleWarning;
        [a addButtonWithTitle:@"OK"];
        if (g_tv_window) [a beginSheetModalForWindow:g_tv_window completionHandler:nil];
        else [a runModal];
    });
}

// settings overlay (overlay_appkit.mm): the Display menu's options
int display_filter() { return g_filter; }
void display_set_filter(int f) {
    g_filter = std::clamp(f, 0, 2);
    save_options();
}
int display_drc_mode() { return g_mode; }
// settings overlay: the Display menu's picture-in-picture choices
void display_set_pip(int corner, float size, float opacity) {
    g_corner = std::clamp(corner, 0, 3);
    g_pip_size = std::clamp(size, 0.1f, 0.5f);
    g_pip_opacity = std::clamp(opacity, 0.2f, 1.0f);
    save_options();
}
void display_set_tv_fullscreen(bool on) {
    if (g_tv_window && is_fullscreen(g_tv_window) != on) [g_tv_window toggleFullScreen:nil];
}
void* display_tv_window() { return (__bridge void*)g_tv_window; }

// mouse camera (mods/mouse.mm): a click on the GamePad overlay is a touch, not a capture
bool drc_overlay_hit(void* window, double wx, double wy) {
    NSWindow* w = (__bridge NSWindow*)window;
    if (!w || w != g_tv_window) return false;
    NSView* v = w.contentView;
    NSPoint p = [v convertPoint:NSMakePoint(wx, wy) fromView:nil];
    NSSize sz = v.bounds.size;
    float tx, ty;
    return sz.width > 0 && sz.height > 0 && overlay_hit(p.x / sz.width, 1.0f - p.y / sz.height, &tx, &ty);
}

// ---------------------------------------------------------------- Display menu
}  // namespace gfx

@interface WWDisplayMenu : NSObject <NSMenuItemValidation, NSMenuDelegate>
@end
@implementation WWDisplayMenu
- (void)fullScreen:(NSMenuItem*)item { [gfx::g_tv_window toggleFullScreen:nil]; }
- (void)setFilter:(NSMenuItem*)item { gfx::g_filter = (int)item.tag; gfx::save_options(); }
- (void)setMode:(NSMenuItem*)item { gfx::set_drc_mode((int)item.tag); }
- (void)toggleDrc:(NSMenuItem*)item { gfx::toggle_drc_screen(); }
- (void)setCorner:(NSMenuItem*)item { gfx::g_corner = (int)item.tag; gfx::save_options(); }
- (void)setSize:(NSMenuItem*)item { gfx::g_pip_size = item.tag / 100.0f; gfx::save_options(); }
- (void)setOpacity:(NSMenuItem*)item { gfx::g_pip_opacity = item.tag / 100.0f; gfx::save_options(); }
- (void)drcScreen:(NSMenuItem*)item {
    NSArray<NSScreen*>* s = NSScreen.screens;
    if (item.tag < 0 || item.tag >= (NSInteger)s.count) return;
    if (gfx::g_mode != gfx::kDrcWindow) gfx::set_drc_mode(gfx::kDrcWindow);
    gfx::show_drc_window(true);
    if (gfx::is_fullscreen(gfx::g_drc_window)) [gfx::g_drc_window toggleFullScreen:nil];
    else gfx::move_drc_to_screen(s[item.tag]);
}
- (void)drcFullScreen:(NSMenuItem*)item {
    if (!gfx::g_drc_window) return;
    if (gfx::g_mode != gfx::kDrcWindow) gfx::set_drc_mode(gfx::kDrcWindow);
    gfx::show_drc_window(true);
    [gfx::g_drc_window toggleFullScreen:nil];
}
- (void)menuNeedsUpdate:(NSMenu*)m {
    [m removeAllItems];
    NSArray<NSScreen*>* s = NSScreen.screens;
    for (NSUInteger i = 0; i < s.count; i++) {
        NSString* t = [NSString stringWithFormat:@"%@%@", s[i].localizedName, s[i] == gfx::g_tv_window.screen ? @" (TV window)" : @""];
        NSMenuItem* it = [m addItemWithTitle:t action:@selector(drcScreen:) keyEquivalent:@""];
        it.target = self;
        it.tag = (NSInteger)i;
    }
}
- (BOOL)validateMenuItem:(NSMenuItem*)item {
    auto on = [&](bool b) { item.state = b ? NSControlStateValueOn : NSControlStateValueOff; };
    SEL a = item.action;
    if (a == @selector(fullScreen:)) item.title = gfx::tv_fullscreen() ? @"Exit Full Screen" : @"Enter Full Screen";
    if (a == @selector(setFilter:)) on(gfx::g_filter == item.tag);
    if (a == @selector(setMode:)) {
        on(gfx::g_mode == item.tag);
        if (item.tag == gfx::kDrcWindow) return gfx::g_drc_window != nil;
    }
    if (a == @selector(toggleDrc:)) {
        item.title = gfx::g_mode == gfx::kDrcAuto ? @"Pin GamePad Picture-in-Picture" : @"Show GamePad Screen";
        on(gfx::drc_window_shown());
        return gfx::g_mode != gfx::kDrcOff && gfx::drc_window_available();
    }
    if (a == @selector(setCorner:)) on(gfx::g_corner == item.tag);
    if (a == @selector(setSize:)) on(fabsf(gfx::g_pip_size * 100 - item.tag) < 0.5f);
    if (a == @selector(setOpacity:)) on(fabsf(gfx::g_pip_opacity * 100 - item.tag) < 0.5f);
    if (a == @selector(drcScreen:)) {
        NSArray<NSScreen*>* s = NSScreen.screens;
        on(gfx::g_drc_window && item.tag < (NSInteger)s.count && gfx::g_drc_window.screen == s[item.tag] &&
           gfx::g_mode == gfx::kDrcWindow);
        return gfx::g_drc_window != nil;
    }
    if (a == @selector(drcFullScreen:)) {
        on(gfx::is_fullscreen(gfx::g_drc_window));
        return gfx::g_drc_window != nil;
    }
    return YES;
}
@end

namespace gfx {

static WWDisplayMenu* g_display_menu;

// the Display menu, added to the menu bar by install_menu (menu.mm)
void install_display_menu(NSMenu* bar) {
    g_display_menu = [WWDisplayMenu new];
    NSMenuItem* top = [bar addItemWithTitle:@"Display" action:nil keyEquivalent:@""];
    NSMenu* m = [[NSMenu alloc] initWithTitle:@"Display"];
    auto add = [&](NSMenu* menu, NSString* title, SEL sel, NSInteger tag = 0, NSString* key = @"",
                   NSEventModifierFlags mods = NSEventModifierFlagCommand) {
        NSMenuItem* it = [menu addItemWithTitle:title action:sel keyEquivalent:key];
        it.keyEquivalentModifierMask = mods;
        it.target = g_display_menu;
        it.tag = tag;
        return it;
    };
    auto header = [&](NSMenu* menu, NSString* title) { [menu addItemWithTitle:title action:nil keyEquivalent:@""].enabled = NO; };
    add(m, @"Enter Full Screen", @selector(fullScreen:), 0, @"f");
    NSMenuItem* alt = add(m, @"Enter Full Screen", @selector(fullScreen:), 0, @"f", NSEventModifierFlagCommand | NSEventModifierFlagControl);
    alt.alternate = YES;  // Ctrl+Cmd+F, the system's full-screen shortcut, does the same
    [m addItem:[NSMenuItem separatorItem]];
    header(m, @"Picture scaling");
    add(m, @"    Smooth (bilinear)", @selector(setFilter:), kSmooth).toolTip = @"Bilinear filtering, box-filtered when the picture is shrunk";
    add(m, @"    Sharp", @selector(setFilter:), kSharp).toolTip = @"Crisp pixel edges at any scale (sharp bilinear)";
    add(m, @"    Integer scale (pixel exact)", @selector(setFilter:), kInteger).toolTip =
        @"Whole-number scale with a border; falls back to Smooth when the picture is larger than the window";
    [m addItem:[NSMenuItem separatorItem]];
    header(m, @"GamePad screen");
    add(m, @"    Separate window", @selector(setMode:), kDrcWindow);
    add(m, @"    Picture-in-picture in the TV window", @selector(setMode:), kDrcPip).toolTip = @"Click the overlay to touch";
    add(m, @"    Automatic picture-in-picture", @selector(setMode:), kDrcAuto).toolTip =
        @"Shows GamePad menus while open; follows Off-TV Play. Cmd+G pins the overlay";
    add(m, @"    Off", @selector(setMode:), kDrcOff).toolTip = @"Not shown; the game keeps drawing it";
    add(m, @"    GamePad only", @selector(setMode:), kDrcGamePad).toolTip =
        @"Only the GamePad picture in the TV window (click it to touch); in the game, Minus switches to Off-TV Play";
    add(m, @"Show GamePad screen", @selector(toggleDrc:), 0, @"g");
    NSMenuItem* pipItem = [m addItemWithTitle:@"Picture-in-picture" action:nil keyEquivalent:@""];
    NSMenu* pm = [[NSMenu alloc] initWithTitle:@"Picture-in-picture"];
    header(pm, @"Corner");
    add(pm, @"    Top left", @selector(setCorner:), 0);
    add(pm, @"    Top right", @selector(setCorner:), 1);
    add(pm, @"    Bottom left", @selector(setCorner:), 2);
    add(pm, @"    Bottom right", @selector(setCorner:), 3);
    header(pm, @"Size (of the TV picture's width)");
    for (int s : {20, 25, 33, 40}) add(pm, [NSString stringWithFormat:@"    %d%%", s], @selector(setSize:), s);
    header(pm, @"Opacity");
    for (int o : {100, 85, 70, 50}) add(pm, [NSString stringWithFormat:@"    %d%%", o], @selector(setOpacity:), o);
    pipItem.submenu = pm;
    NSMenuItem* scrItem = [m addItemWithTitle:@"GamePad window on display" action:nil keyEquivalent:@""];
    NSMenu* sm = [[NSMenu alloc] initWithTitle:@"GamePad window on display"];
    sm.delegate = g_display_menu;
    scrItem.submenu = sm;
    add(m, @"GamePad window full screen", @selector(drcFullScreen:));
    top.submenu = m;
}

}  // namespace gfx

#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <string_view>
#include <vector>
#include "ray_reflections.h"

namespace gfx::rt_capture {
constexpr uint32_t vertices = 65 * 65, stride = 32, vb_bytes = vertices * stride;
inline bool enabled() {
    static const bool on = [] { const char* e = std::getenv("WWHD_RT_CAPTURE"); return e && !std::strcmp(e, "1"); }();
    return on;
}
inline std::atomic<bool> finished{false};
inline bool tracking() { return (enabled() && !finished.load()) || ray_reflections::requested(); }
struct Sea {
    uint32_t packet = 0, vb = 0, camera = 0;
    std::array<char,9> stage{};
    uint8_t eventMode = 0;
    uint64_t pass = 0;
    std::array<float, 16> pv{}, projection{};
    std::array<float, 12> view{};
    std::array<float, 3> eye{};
    std::vector<uint8_t> bytes;
};
// Verified against the M5 VS/support capture. Other shader layouts fail closed.
inline bool sea_transform(std::string_view source, const void* support, size_t size, Sea& out) {
    if (source.find("// shader 8d585a2172b7d624") == std::string_view::npos || size < 160 ||
        source.find("SET_POSITION(float4(R1f.x, R1f.y, R1f.z, R1f.w));") == std::string_view::npos) return false;
    float words[40]; std::memcpy(words,support,sizeof(words));
    for (float f:words) if (!std::isfinite(f)) return false;
    for (int r=0;r<3;++r) for(int c=0;c<4;++c)
        if (std::abs(words[4*r+c]-(r==c ? 1.0f : 0.0f))>1e-7f) return false;
    // The actual shader performs identity model -> affine view -> perspective projection.
    std::array<float,16> view{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
    std::copy(words+12,words+24,view.begin());
    std::copy(words+24,words+40,out.projection.begin());
    if (out.projection[12]!=0 || out.projection[13]!=0 || out.projection[14]!=-1 || out.projection[15]!=0 ||
        out.projection[0]<=0 || out.projection[5]<=0 || out.projection[10]>=-1 || out.projection[11]>=0) return false;
    for(int r=0;r<3;++r)for(int k=0;k<3;++k) {
        double d=0; for(int c=0;c<3;++c)d+=double(view[4*r+c])*view[4*k+c];
        if(std::abs(d-(r==k ? 1.0 : 0.0))>.001) return false;
    }
    for(int r=0;r<4;++r)for(int c=0;c<4;++c) {
        double v=0; for(int k=0;k<4;++k)v+=double(out.projection[4*r+k])*view[4*k+c];
        out.pv[4*r+c]=float(v);
    }
    std::copy(view.begin(),view.begin()+12,out.view.begin());
    for(int r=0;r<3;++r) {
        double eye=0; for(int k=0;k<3;++k)eye-=double(view[4*k+r])*view[4*k+3];
        out.eye[r]=float(eye);
    }
    return true;
}
inline std::mutex mutex;
inline std::deque<std::shared_ptr<const Sea>> recent;
inline void publish(Sea s) {
    if (!tracking() || s.bytes.size() != vb_bytes) return;
    std::lock_guard<std::mutex> lock(mutex);
    recent.push_back(std::make_shared<const Sea>(std::move(s)));
    if (recent.size() > 8) recent.pop_front();
}
inline std::shared_ptr<const Sea> match(uint32_t addr, const void* data, size_t size) {
    if (!tracking() || size < vb_bytes) return {};
    std::lock_guard<std::mutex> lock(mutex);
    for (auto i = recent.rbegin(); i != recent.rend(); ++i)
        if ((*i)->vb == addr && !std::memcmp((*i)->bytes.data(), data, vb_bytes)) return *i;
    return {};
}
// Fail closed when the generated entry point or reserved diagnostic slots differ.
inline bool instrument(std::string& s) {
    const std::string entry = "vertex VertexOut main0(";
    size_t start = s.find(entry), ret = s.rfind("return out;");
    if (start == std::string::npos || ret == std::string::npos || ret < start ||
        s.find("[[buffer(29)]]") != std::string::npos || s.find("[[buffer(30)]]") != std::string::npos ||
        s.find("device int* sb") != std::string::npos) return false;
    size_t end = s.find(") {", start);
    if (end == std::string::npos || end > ret || s.find("uint vid [[vertex_id]]", start) > end ||
        s.find("uint iid [[instance_id]]", start) > end) return false;
    s.insert(ret, "if (iid == 0 && vid < 4225 && atomic_exchange_explicit(&rtClaim[vid], 1u, memory_order_relaxed) == 0) rtClip[vid] = out.position;\n");
    s.insert(end, ", device atomic_uint* rtClaim [[buffer(29)]], device float4* rtClip [[buffer(30)]]");
    return true;
}
inline float be_float(const uint8_t* p) {
    uint32_t u = (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
    float f; std::memcpy(&f, &u, 4); return f;
}
inline std::array<double, 4> project(const Sea& s, uint32_t id, bool halfZ) {
    const uint8_t* v = s.bytes.data() + id * stride;
    double world[4] = {be_float(v), be_float(v + 4), be_float(v + 8), 1};
    std::array<double, 4> out{};
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) out[r] += s.pv[4*r+c] * world[c];
    if (!halfZ) out[2] = (out[2] + out[3]) * .5;
    return out;
}
inline bool visible_strip(const Sea& sea, const std::vector<uint32_t>& indices, uint32_t count, bool halfZ) {
    // This is selection only; the real GPU output/depth still decide validation.
    const size_t n=indices.empty()?count:indices.size();
    uint32_t inside=0;
    for(size_t k=0;k<n;++k) {
        uint32_t id=indices.empty()?uint32_t(k):indices[k];
        if(id>=vertices)return false;
        auto p=project(sea,id,halfZ);
        if(p[3]>0 && std::isfinite(p[3]) && std::abs(p[0]/p[3])<.9 && std::abs(p[1]/p[3])<.9 &&
            p[2]/p[3]>0 && p[2]/p[3]<1 && ++inside>=16) return true;
    }
    return false;
}
inline bool inverse(const std::array<float, 16>& m, bool halfZ, std::array<double, 16>& out) {
    double a[4][8]{};
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
        a[r][c] = m[4*r+c];
        if (!std::isfinite(a[r][c])) return false;
    }
    if (!halfZ) for (int c = 0; c < 4; ++c) a[2][c] = .5*(a[2][c]+a[3][c]);
    for (int r = 0; r < 4; ++r) a[r][r+4] = 1;
    for (int c = 0; c < 4; ++c) {
        int p = c;
        for (int r = c+1; r < 4; ++r) if (std::abs(a[r][c]) > std::abs(a[p][c])) p = r;
        if (std::abs(a[p][c]) < 1e-14) return false;
        for (int k = 0; k < 8; ++k) std::swap(a[p][k], a[c][k]);
        double d = a[c][c];
        for (double& v : a[c]) v /= d;
        for (int r = 0; r < 4; ++r) if (r != c) {
            d = a[r][c];
            for (int k = 0; k < 8; ++k) a[r][k] -= d*a[c][k];
        }
    }
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) {
        out[4*r+c] = a[r][c+4];
        if (!std::isfinite(out[4*r+c])) return false;
    }
    return true;
}
struct Validation { uint32_t checked = 0, bad = 0; double max_relative_error = 0; };
inline Validation validate_clip(const Sea& sea, const uint32_t* claimed, const float* clips, bool halfZ) {
    Validation out;
    for (uint32_t i = 0; i < vertices; ++i) if (claimed[i]) {
        auto expected = project(sea, i, halfZ);
        bool bad = false;
        for (int c = 0; c < 4; ++c) {
            const double actual = clips[4*i+c];
            double relative = std::abs(actual-expected[c]) / std::max(1.0, std::abs(expected[c]));
            if (!std::isfinite(actual) || !std::isfinite(relative)) relative = 1e30;
            out.max_relative_error = std::max(out.max_relative_error, relative);
            bad |= relative > 0.0002;
        }
        ++out.checked; out.bad += bad;
    }
    return out;
}
struct DepthValidation { uint32_t tested=0, matched=0; bool passed=false; };
inline DepthValidation validate_depth(const std::vector<uint32_t>& indices, bool strip, const uint32_t* claims,
        const float* clips, const float* depths, size_t width, size_t height, const std::array<double,6>& vp,
        const std::array<size_t,4>& scissor, double tolerance) {
    DepthValidation out;
    double minX=1e30,maxX=-1e30,minY=1e30,maxY=-1e30;
    for (size_t k=0;k+2<indices.size();k+=strip?1:3) {
        uint32_t ids[3]={indices[k],indices[k+1],indices[k+2]};
        double x[3],y[3],z[3]; bool usable=true;
        for (int j=0;j<3;++j) {
            if(ids[j]>=vertices) { usable=false; break; }
            const float* p=clips+4*ids[j];
            if (!claims[ids[j]] || !std::isfinite(p[3]) || p[3]<=0) { usable=false; break; }
            x[j]=vp[0]+(p[0]/p[3]+1)*.5*vp[2]; y[j]=vp[1]+(1-p[1]/p[3])*.5*vp[3];
            z[j]=vp[4]+p[2]/p[3]*(vp[5]-vp[4]);
            usable &= std::isfinite(x[j]) && std::isfinite(y[j]) && std::isfinite(z[j]);
        }
        if (!usable) continue;
        double area=(y[1]-y[2])*(x[0]-x[2])+(x[2]-x[1])*(y[0]-y[2]);
        if (std::abs(area)<4) continue;
        double px=std::floor((x[0]+x[1]+x[2])/3)+.5, py=std::floor((y[0]+y[1]+y[2])/3)+.5;
        if (px<scissor[0] || py<scissor[1] || px>=scissor[0]+scissor[2] || py>=scissor[1]+scissor[3] ||
            px<0 || py<0 || px>=width || py>=height) continue;
        double a=((y[1]-y[2])*(px-x[2])+(x[2]-x[1])*(py-y[2]))/area;
        double b=((y[2]-y[0])*(px-x[2])+(x[0]-x[2])*(py-y[2]))/area, d=1-a-b;
        if (a<0 || b<0 || d<0) continue;
        double expected=a*z[0]+b*z[1]+d*z[2];
        float actual=depths[size_t(py)*width+size_t(px)];
        if (expected<=0 || expected>=1 || actual<=0 || actual>=1 || !std::isfinite(actual)) continue;
        ++out.tested;
        if (std::abs(actual-expected)<=tolerance) {
            ++out.matched; minX=std::min(minX,px); maxX=std::max(maxX,px); minY=std::min(minY,py); maxY=std::max(maxY,py);
        }
    }
    out.passed=out.matched>=16 && maxX-minX>=vp[2]*.1 && maxY-minY>=vp[3]*.03;
    return out;
}
// Search actual bound bytes, allowing native/big endian and row/column-major packing.
inline bool contains_matrix(const void* data, size_t size, const std::array<float,16>& matrix) {
    const auto* p = static_cast<const uint8_t*>(data);
    for (size_t off = 0; off+64 <= size; off += 4) for (bool big : {false,true}) for (bool transpose : {false,true}) {
        bool same = true;
        for (int j = 0; j < 16; ++j) {
            float value; std::memcpy(&value, p+off+4*j, 4);
            if (big) value = be_float(p+off+4*j);
            float expected = matrix[transpose ? 4*(j%4)+j/4 : j];
            if (!std::isfinite(value) || !std::isfinite(expected) ||
                std::abs(value-expected) > 1e-6*std::max(1.0, double(std::abs(expected)))) { same = false; break; }
        }
        if (same) return true;
    }
    return false;
}
} // namespace gfx::rt_capture

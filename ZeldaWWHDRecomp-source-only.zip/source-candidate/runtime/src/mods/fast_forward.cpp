// SPDX-License-Identifier: MPL-2.0
// Event gating/display-clock acceleration adapted from GreenNaugahyde's
// ZeldaWWHDRecompAndroid 9551a2508c9eb6f4417ee27116f998237d52addc, mods/turbo.cpp.
#include "fast_forward.h"
#include "mods.h"
#include "../game_clock.h"
#include "../audio_out.h"
#include "guest_addr.h"
#include "../runtime.h"
#include "../overlay/overlay.h"
#include <atomic>
#include <array>
#include <cstdlib>
#include <cstring>
#ifdef WWHD_IOS
#include "../platform/ios/ios.h"
#endif
namespace mods {
namespace {
unsigned env(const char* name, unsigned fallback) {
    const char* s = std::getenv(name);
    if (!s || !*s || *s == '-') return fallback;
    char* end = nullptr;
    unsigned long n = std::strtoul(s, &end, 0);
    return *end || n > UINT32_MAX ? fallback : unsigned(n);
}
std::atomic<bool> enabled{env("WWHD_MOD_FAST_FORWARD", 0) != 0};
std::atomic<bool> global{env("WWHD_MOD_FF_GLOBAL", 0) != 0};
std::atomic<unsigned> speed{[] { auto n = env("WWHD_MOD_FF_RATE", 2); return n >= 2 && n <= 4 ? n : 2; }()};
std::atomic<uint32_t> button{[] { auto n = env("WWHD_MOD_FF_BUTTON", 0x40); return valid_fast_forward_button(n) ? n : 0x40; }()};
std::atomic<bool> mute{env("WWHD_MOD_FF_MUTE", 1) != 0};
std::atomic<bool> active{false}, release_required{false};
std::atomic<bool> latched{false};
std::atomic<uint32_t> held{0};
const uint32_t play = GD(0x1046F0B0);
// HD d_s_open / hd_scene_opening: singleton -> mpScreen (+0x94). Unlike the
// sea_T title background, this picture story has its own loaded Opening_00 screen.
bool guest_object(uint32_t p, uint32_t size) {
    return p >= mem::kMem2Start && p <= mem::kMem2End - size && !(p & 3);
}
bool eligible(uint32_t buttons, bool diagnostic = false) {
    bool controls = false;
#ifdef WWHD_IOS
    controls = ios::controls_block_input();
#endif
    const char* stage = reinterpret_cast<const char*>(mem::ptr(play + 0x5134));
    const uint32_t opening = ld32(GD(0x101F8318));
    const uint32_t screen = guest_object(opening, 0x98) ? ld32(opening + 0x94) : 0;
    const bool opening_story = guest_object(screen, 0x8C) &&
        ld32(screen + 4) == GD(0x100FFED0) && ld32(screen + 0x44) != 0 &&
        !ld8(screen + 0x88); // hdOpening_screen_c: mpLayout, mFinished
    const unsigned event = ld8(play + 0x5292);
    const unsigned message = ld8(play + 0x5BB2), scope_message = ld8(play + 0x5BB3);
    const bool story_stage = *stage && std::strncmp(stage, "sea_T", 8) && std::strncmp(stage, "Name", 8);
    // A story event need not contain Link (opening/ending camera cuts). Message
    // status also covers dialogue outside dEvt_control_c modes TALK/DEMO/COMPULSORY.
    const bool story = opening_story || (story_stage &&
        ((event >= 1 && event <= 3) || message || scope_message));
    // Require a live gameplay actor outside story scenes; stale stage fields in
    // boot/title/file selection must never start the accelerated clock.
    const uint32_t link = ld32(play + 0x5B34);
    const bool gameplay = story_stage && guest_object(link, 4);
    const bool next = ld8(play + 0x5140 + 12) != 0;
    const bool overlap = ld32(GD(0x101F36CC)) != 0;
    const bool menu = ld8(GD(0x101EA069)) != 0;
    const bool blocked = overlay::blocks_input() || controls;
    const bool result = fast_forward_gate(fast_forward(), (story || (fast_forward_global() && gameplay)) ? 1 : 0,
        !next && !overlap, menu, blocked, buttons, fast_forward_button());
    if (diagnostic && trace_on()) {
        const std::array<uint32_t, 15> state = {event, message, scope_message, opening, screen,
            unsigned(opening_story), unsigned(next), unsigned(overlap), unsigned(menu),
            unsigned(blocked), unsigned(latched.load()), unsigned(release_required.load()),
            unsigned(fast_forward_global()), link,
            (buttons & fast_forward_button()) ? fast_forward_rate() : 0};
        static std::array<uint32_t, 15> last{};
        static char last_stage[8]{};
        static bool logged = false;
        if (!logged || state != last || std::memcmp(last_stage, stage, 8)) {
            trace("ff gate stage=%.8s event=%u msg=%u scope=%u opening=%08X screen=%08X "
                  "opening_active=%u next=%u overlap=%u menu=%u blocked=%u armed=%u release=%u "
                  "global=%u link=%08X request_rate=%u eligible=%u", stage, event, message, scope_message, opening, screen,
                  unsigned(opening_story), unsigned(next), unsigned(overlap), unsigned(menu),
                  unsigned(blocked), unsigned(latched.load()), unsigned(release_required.load()),
                  unsigned(fast_forward_global()), link,
                  state.back(), unsigned(result));
            last = state;
            std::memcpy(last_stage, stage, 8);
            logged = true;
        }
    }
    return result;
}
}
bool fast_forward() { return enabled.load(); }
void set_fast_forward(bool on) { enabled = on; if (!on) fast_forward_reset(); }
bool fast_forward_global() { return global.load(); }
void set_fast_forward_global(bool on) {
    // Preserve the user's armed switch, but drop the old rate immediately;
    // service() re-evaluates the new scope at the next safe frame boundary.
    if (global.exchange(on) != on) timebase::set_clock_rate(1);
}
unsigned fast_forward_rate() { return speed.load(); }
void set_fast_forward_rate(unsigned r) { if (r >= 2 && r <= 4) speed = r; }
uint32_t fast_forward_button() { return button.load(); }
void set_fast_forward_button(uint32_t b) {
    if (valid_fast_forward_button(b) && button.exchange(b) != b) fast_forward_reset();
}
bool fast_forward_mute() { return mute.load(); }
void set_fast_forward_mute(bool on) { mute = on; }
bool fast_forward_active() { return active.load(); }
bool fast_forward_latched() { return latched.load(); }
void set_fast_forward_latched(bool on) {
    latched=on;
    if(on) { enabled=true; release_required=false; }
    else fast_forward_reset();
}
void fast_forward_reset() {
    latched=false;
    if (!fast_forward() && !active.load()) return;
    release_required = true;
    held = 0;
    timebase::set_clock_rate(1);
    // The pass mode is changed only by service(), at a safe frame boundary.
}
void fast_forward_input(uint32_t& buttons) {
    if (!fast_forward()) return;
    held = buttons;
    if (!(buttons & fast_forward_button())) release_required = false;
    if (!latched.load() && !release_required.load() && eligible(buttons)) buttons &= ~fast_forward_button();
}
void fast_forward_service() {
    if (!fast_forward() && !active.load()) return;
    const bool allowed = eligible(held.load() | (latched.load() ? fast_forward_button() : 0), true);
    const bool on = !release_required.load() && allowed;
    const unsigned rate = on ? fast_forward_rate() : 1;
    const bool transition = active.exchange(on) != on;
    const bool rate_change = game_clock::rate() != rate;
    if (transition || rate_change) {
        audio::flush(); // discard queued output at the boundary, never guest audio callbacks
    }
    timebase::set_clock_rate(rate);
    if (transition || rate_change) {
        const auto sample = game_clock::sample();
        trace("fast forward %s (%ux) global=%u host_ns=%lld guest_ns=%lld", on ? "on" : "off", rate,
              unsigned(fast_forward_global()), static_cast<long long>(sample.host), static_cast<long long>(sample.guest));
    }
}
}

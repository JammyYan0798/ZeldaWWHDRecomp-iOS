# WWHD Settings Sans SC

This is a static regular (weight 400) subset of Google Fonts' Noto Sans SC variable font, packaged for the iOS ImGui settings UI. The subset retains Basic Latin and characters present in the overlay source, plus △○×□. ImGui still requests glyphs dynamically as text is drawn; this file does not contain a prebuilt atlas.

Source: [Google Fonts Noto Sans SC](https://github.com/google/fonts/tree/main/ofl/notosanssc), `NotoSansSC[wght].ttf` (downloaded 2026-10-21; source SHA-256 `a3041811a78c361b1de50f953c805e0244951c21c5bd412f7232ef0d899af0da`). Variable weight axis instantiated at 400 and font family renamed for the modified derivative. See `OFL.txt` for the SIL Open Font License 1.1.

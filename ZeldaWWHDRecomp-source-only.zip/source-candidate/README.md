# The Legend of Zelda: The Wind Waker HD — iOS / iPadOS

**中文 / English** · iOS 源码分支 / iOS source branch · 版本 / Version **0.1 (11)**

## 项目简介 / Overview

这是基于 [ZeldaWWHDRecomp](https://github.com/ZeldaWWHDRecomp/ZeldaWWHDRecomp) 的 iPhone 与 iPad 移植。源码包不包含游戏文件、密钥、签名证书或从游戏数据生成的代码；构建者必须自行准备合法取得的游戏副本。

This iPhone and iPad port is based on [ZeldaWWHDRecomp](https://github.com/ZeldaWWHDRecomp/ZeldaWWHDRecomp). The source package contains no game files, keys, signing certificates, or code generated from game data. Builders must provide their own legally obtained game copy.

## 移植路线 / Porting path

- **静态重编译 / Static recompilation.** 上游工具在构建时把 Wii U PowerPC 游戏函数转换为 C/C++，再由 Xcode 编译为 iOS arm64 原生代码。 / Upstream tools translate Wii U PowerPC game functions into C/C++ ahead of time, then Xcode compiles them for native iOS arm64.
- **宿主适配 / Host adaptation.** macOS 的 AppKit 窗口、事件和输入宿主由 UIKit 应用入口接管；UIKit view 通过 `CAMetalLayer` 呈现，共享 Metal 渲染器与 GX2 资源管线。 / UIKit replaces the macOS AppKit window, event, and input host. A UIKit view presents through `CAMetalLayer`, while the Metal renderer and GX2 resource path are shared.
- **构建目标 / Build target.** `ios/build.py` 配置 CMake 的 Xcode generator，目标为 `iphoneos`、`arm64`、Metal，最低部署目标 iOS 17。正式构建需要用户提供原版游戏目录、自己的 Xcode Team ID 和 Bundle ID。 / `ios/build.py` configures CMake's Xcode generator for `iphoneos`, `arm64`, and Metal, with an iOS 17 deployment target. A full build requires the user's original game directory, Xcode Team ID, and Bundle ID.

## 内存与图形性能路径 / Memory and graphics performance

- **来宾内存 / Guest address space.** iOS 在固定基址预留 4 GiB 虚拟地址空间来匹配游戏地址布局；它不是 4 GiB 的物理内存占用，实际 footprint 随已触及页面和图形资源变化。 / iOS reserves a 4 GiB virtual address range at a fixed base for the game's address layout; it is not a 4 GiB physical RAM allocation, and actual memory use depends on touched pages and graphics resources.
- **Metal 复用 / Metal reuse.** 共用 GX2 到 Metal 渲染路径；安全匹配时复用 Metal 函数与管线，并合并连续资源复制操作。 / The shared GX2-to-Metal path reuses Metal functions and pipelines when descriptors match safely, and batches consecutive resource-copy work.
- **按需工作 / On-demand work.** iOS 默认关闭高级内部渲染 profiler；诊断时可设置 `WWHD_PROFILE=1`，性能 HUD 按需显示。着色器与管线按场景实际需要创建，不在启动时重放大批历史预热记录。 / The advanced internal renderer profiler is off by default on iOS; set `WWHD_PROFILE=1` for diagnostics and show the performance HUD when needed. Shaders and pipelines are created as the scene needs them instead of replaying large historical warm-up lists at launch.
- **分辨率与重建 / Resolution and upscaling.** 可选标准 1×、屏幕原生或 MetalFX SpatialScaler 空间重建；下表记录一次 MetalFX 75% 输入比例的场景测量。 / Choose standard 1×, native display resolution, or optional MetalFX SpatialScaler upscaling; the table below records one scene measured at 75% input scale.
- **帧节奏 / Frame pacing.** 60 fps 插帧仍基于原版 **30 Hz 游戏逻辑**；输出接近 60 fps 不代表逻辑以 60 Hz 运行，也不保证所有场景锁定 60 fps。 / 60 fps interpolation retains the original **30 Hz game logic**; output near 60 fps does not mean 60 Hz logic or guarantee a 60 fps lock in every scene.

触控操作与 GameController 手柄输入均可用。Touch controls and GameController input are available.

## Build 11 单场景记录 / Build 11 scene record

| 项目 / Metric | 实测 / Result |
| --- | --- |
| 场景与时长 / Scene and duration | 海面静置（无玩家输入），60 秒 / Static ocean scene (no player input), 60 seconds |
| 设备 / Device | 11 英寸 M5 iPad Pro / 11-inch M5 iPad Pro |
| 内部渲染 → 输出 / Internal render → output | 1815×1251 → 2420×1668 |
| MetalFX 输入比例 / MetalFX input scale | 宽高各 75% / 75% of output width and height |
| 平均帧率 / Average FPS | 59.95 fps |
| 1%低帧 / 0.1%低帧 · 1% / 0.1% low | 54.34 / 34.29 fps |
| 系统热状态 / Thermal state | `0`（系统状态值，不是摄氏度） / `0` (system state value, not degrees Celsius) |
| 进程物理内存 / Process physical footprint | 约 1.17 GiB（仅此场景） / About 1.17 GiB (this scene only) |

这是单设备、单场景、单次 60 秒记录，不代表其他场景或设备，也不构成全程锁帧承诺。This is one 60-second run on one device and scene; it does not represent other scenes or devices and is not a frame-rate guarantee.

## 从源码构建 / Build from source

需要 Mac、带 iOS SDK 的 Xcode、Python 3、CMake，以及自己的签名 Team。自行准备原版 USA/EUR v0 游戏目录，再运行：

You need a Mac, Xcode with the iOS SDK, Python 3, CMake, and your own signing Team. Prepare an unmodified USA/EUR v0 game directory, then run:

```sh
GAME_DIR="/path/to/your/original/game"
python3 ios/build.py --check-game --game "$GAME_DIR"
python3 ios/build.py --game "$GAME_DIR" --team YOUR_TEAM_ID --bundle-id org.example.wwhd
```

完整构建说明、数据放置方式和设置说明见 [ios/README.md](ios/README.md)。Full build, game-data placement, and setup instructions are in [ios/README.md](ios/README.md).

## 致谢与许可 / Attribution and licenses

本分支保留上游署名、根目录 MPL-2.0 许可及所有第三方许可证和来源说明。详见 [上游完整 README 与 Credits](README.upstream.md#credits)、[法律说明](README.upstream.md#legal-notice)、[LICENSE](LICENSE) 和各依赖目录中的许可文件。This branch retains upstream attribution, the root MPL-2.0 license, and all third-party licenses and notices. See the [complete upstream README and credits](README.upstream.md#credits), [legal notice](README.upstream.md#legal-notice), [LICENSE](LICENSE), and license files in dependency directories.
